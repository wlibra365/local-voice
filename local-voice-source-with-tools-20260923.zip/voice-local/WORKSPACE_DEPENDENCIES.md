# 作業環境と再ビルドに必要なもの

このプロジェクトは、Android SDKそのものやビルド生成物をリポジトリに含めません。
再ビルド時は次の環境を用意します。

## 必須

- JDK 17
- Android SDK Platform API 35
- Android SDK Build Tools 35.0.0
- `ANDROID_SDK_ROOT` または `ANDROID_HOME`

`build-apk.sh` が `javac`、`d8`、`aapt2`、`zipalign`、`apksigner` を直接呼び出します。GradleのキャッシュやAndroid SDKは、作業環境側に保持します。

## 再ビルド

```bash
cd voice-local
./build-apk.sh
```

出力先は `app/build/outputs/apk/debug/local-voice-debug.apk` です。

## テスト

```bash
bash tests/run.sh
```

## リポジトリに含めないもの

- `app/build/` 以下の生成物
- `.gradle/`、`.idea/`、`local.properties`
- デバッグ用キーストア
- APK、AAR、ONNX、チェックポイントなどの大容量バイナリ

大容量モデルを再導入する場合は、モデルのSHA-256、ライセンス、取得元URLを `models/` に記録し、実体はGitHub ReleaseまたはGit LFSで別管理します。

## 現在の音声エンジン

このソースパッケージの通常処理は、Java DSP（`Dsp` / `FormantWarp`）です。`LlvcStreamBridge` とモデル検証ツールは、後段のLLVC接続・検証用です。APKへモデルを同梱した版を作る場合は、モデルと推論ランタイムの版、ハッシュ、実機確認結果を必ず更新します。
