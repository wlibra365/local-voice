#!/usr/bin/env python3
"""Validate an offline voice-model package before it enters the Android build."""

from __future__ import annotations

import argparse
import hashlib
import json
import tempfile
from pathlib import Path


REQUIRED = {
    "schema_version", "engine_id", "display_name", "runtime", "model_format", "model_file",
    "model_sha256", "sample_rate_hz", "input_channels", "streaming",
    "stateful", "frame_samples",
    "license_spdx", "license_file", "source_url", "checkpoint_source_url",
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def validate(manifest_path: Path) -> dict[str, object]:
    data = json.loads(manifest_path.read_text(encoding="utf-8"))
    missing = sorted(REQUIRED - data.keys())
    if missing:
        raise ValueError("不足項目: " + ", ".join(missing))
    if data["schema_version"] != 1:
        raise ValueError("未対応schema_version")
    if data["input_channels"] != 1 or data["sample_rate_hz"] not in (16000, 24000, 32000, 44100, 48000):
        raise ValueError("音声形式が未対応")
    if data["streaming"] is not True:
        raise ValueError("リアルタイム候補はstreaming=trueが必要")
    if data["stateful"] is not True or not isinstance(data["frame_samples"], int) or not 1 <= data["frame_samples"] <= 8192:
        raise ValueError("ストリーミング状態またはフレーム長が不正")
    for key in ("source_url", "checkpoint_source_url"):
        if not isinstance(data[key], str) or not data[key].startswith("https://"):
            raise ValueError(f"{key}が不正")
    root = manifest_path.parent
    model = root / str(data["model_file"])
    license_path = root / str(data["license_file"])
    if not model.is_file() or not license_path.is_file():
        raise ValueError("モデルまたはライセンスファイルがありません")
    expected = str(data["model_sha256"])
    if len(expected) != 64 or expected.lower() != expected or any(c not in "0123456789abcdef" for c in expected):
        raise ValueError("model_sha256が不正")
    actual = sha256(model)
    if actual != expected:
        raise ValueError("モデルSHA-256不一致")
    if license_path.stat().st_size < 20:
        raise ValueError("ライセンス本文が空または短すぎます")
    return {"engine_id": data["engine_id"], "model_sha256": actual, "model_bytes": model.stat().st_size,
            "sample_rate_hz": data["sample_rate_hz"], "license_spdx": data["license_spdx"]}


def self_test() -> None:
    with tempfile.TemporaryDirectory() as directory:
        root = Path(directory)
        model = root / "model.bin"
        model.write_bytes(b"local voice candidate model test")
        (root / "LICENSE.txt").write_text("MIT License test fixture only", encoding="utf-8")
        manifest = {
            "schema_version": 1, "engine_id": "test", "display_name": "test", "runtime": "test", "model_format": "test",
            "model_file": model.name, "model_sha256": sha256(model), "sample_rate_hz": 16000,
            "input_channels": 1, "streaming": True, "stateful": True, "frame_samples": 208, "license_spdx": "MIT",
            "license_file": "LICENSE.txt", "source_url": "https://example.invalid/source",
            "checkpoint_source_url": "https://example.invalid/model",
        }
        path = root / "model-package.json"
        path.write_text(json.dumps(manifest), encoding="utf-8")
        validate(path)
        manifest["model_sha256"] = "0" * 64
        path.write_text(json.dumps(manifest), encoding="utf-8")
        try:
            validate(path)
            raise AssertionError("hash mismatch accepted")
        except ValueError as error:
            if "SHA-256" not in str(error):
                raise
    print("PASS model package manifest, license presence and SHA-256 rejection")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("manifest", nargs="?", type=Path)
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()
    if args.self_test:
        self_test()
    elif args.manifest:
        print(json.dumps(validate(args.manifest), ensure_ascii=False, indent=2))
    else:
        parser.error("manifestが必要です")


if __name__ == "__main__":
    main()
