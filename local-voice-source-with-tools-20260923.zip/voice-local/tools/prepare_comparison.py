#!/usr/bin/env python3
"""Align and loudness-match two PCM16 mono WAV files for listening tests."""

from __future__ import annotations

import argparse
import csv
import json
import math
import tempfile
import wave
from pathlib import Path

import numpy as np


def read_wav(path: Path) -> tuple[int, np.ndarray]:
    with wave.open(str(path), "rb") as source:
        if source.getnchannels() != 1 or source.getsampwidth() != 2:
            raise ValueError(f"{path}: PCM16 mono WAVのみ対応")
        rate = source.getframerate()
        samples = np.frombuffer(source.readframes(source.getnframes()), dtype="<i2")
    if samples.size == 0:
        raise ValueError(f"{path}: 音声が空です")
    return rate, samples.astype(np.float64) / 32768.0


def write_wav(path: Path, rate: int, samples: np.ndarray) -> int:
    clipped = int(np.count_nonzero(np.abs(samples) > 0.999))
    pcm = np.rint(np.clip(samples, -0.999, 0.999) * 32767.0).astype("<i2")
    with wave.open(str(path), "wb") as target:
        target.setnchannels(1)
        target.setsampwidth(2)
        target.setframerate(rate)
        target.writeframes(pcm.tobytes())
    return clipped


def estimate_lag(reference: np.ndarray, candidate: np.ndarray, rate: int) -> tuple[int, float]:
    # A bounded excerpt keeps memory predictable while covering normal tuning samples.
    limit = min(reference.size, candidate.size, rate * 20)
    a = reference[:limit] - np.mean(reference[:limit])
    b = candidate[:limit] - np.mean(candidate[:limit])
    maximum = min(rate * 2, limit - 1)
    size = 1 << int(math.ceil(math.log2(a.size + b.size)))
    correlation = np.fft.irfft(np.fft.rfft(b, size) * np.conj(np.fft.rfft(a, size)), size)
    lags = np.arange(-maximum, maximum + 1, dtype=np.int64)
    indices = np.where(lags >= 0, lags, size + lags)
    values = correlation[indices]
    position = int(np.argmax(np.abs(values)))
    lag = int(lags[position])
    denominator = float(np.linalg.norm(a) * np.linalg.norm(b))
    confidence = 0.0 if denominator == 0 else float(abs(values[position]) / denominator)
    return lag, min(1.0, confidence)


def align(reference: np.ndarray, candidate: np.ndarray, lag: int) -> tuple[np.ndarray, np.ndarray]:
    reference_start = max(0, -lag)
    candidate_start = max(0, lag)
    count = min(reference.size - reference_start, candidate.size - candidate_start)
    if count <= 0:
        raise ValueError("位置合わせ後の共通区間がありません")
    return reference[reference_start:reference_start + count], candidate[candidate_start:candidate_start + count]


def rms(samples: np.ndarray) -> float:
    return float(np.sqrt(np.mean(np.square(samples)))) if samples.size else 0.0


def prepare(reference_path: Path, candidate_path: Path, output_dir: Path) -> dict[str, object]:
    reference_rate, reference = read_wav(reference_path)
    candidate_rate, candidate = read_wav(candidate_path)
    if reference_rate != candidate_rate:
        raise ValueError(f"サンプルレート不一致: {reference_rate} / {candidate_rate}")
    lag, confidence = estimate_lag(reference, candidate, reference_rate)
    aligned_reference, aligned_candidate = align(reference, candidate, lag)
    reference_rms = rms(aligned_reference)
    candidate_rms = rms(aligned_candidate)
    if reference_rms < 1e-5 or candidate_rms < 1e-5:
        raise ValueError("音量が小さすぎて比較できません")
    gain = float(np.clip(reference_rms / candidate_rms, 0.25, 4.0))
    matched_candidate = aligned_candidate * gain
    output_dir.mkdir(parents=True, exist_ok=True)
    reference_out = output_dir / "reference_aligned.wav"
    candidate_out = output_dir / "candidate_aligned.wav"
    write_wav(reference_out, reference_rate, aligned_reference)
    clipped = write_wav(candidate_out, reference_rate, matched_candidate)
    report: dict[str, object] = {
        "reference": str(reference_path),
        "candidate": str(candidate_path),
        "sample_rate_hz": reference_rate,
        "aligned_samples": int(aligned_reference.size),
        "aligned_duration_seconds": aligned_reference.size / reference_rate,
        "candidate_delay_samples": lag,
        "candidate_delay_ms": lag * 1000.0 / reference_rate,
        "correlation_confidence": confidence,
        "reference_rms": reference_rms,
        "candidate_rms_before_match": candidate_rms,
        "candidate_gain_for_comparison": gain,
        "candidate_peak_after_match": float(np.max(np.abs(matched_candidate))),
        "candidate_clipped_samples": clipped,
    }
    (output_dir / "measurement.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    with (output_dir / "rating.csv").open("w", newline="", encoding="utf-8-sig") as target:
        writer = csv.writer(target)
        writer.writerow(["評価者", "候補", "女性声らしさ(1-5)", "透明感(1-5)", "自然さ(1-5)", "明瞭さ(1-5)", "コメント"])
        writer.writerow(["", candidate_path.stem, "", "", "", "", ""])
    return report


def self_test() -> None:
    rate = 48000
    count = rate * 2
    time = np.arange(count) / rate
    reference = 0.18 * np.sin(2 * np.pi * 220 * time) + 0.07 * np.sin(2 * np.pi * 510 * time)
    delay = 1379
    candidate = np.concatenate([np.zeros(delay), reference * 0.42, np.zeros(500)])
    with tempfile.TemporaryDirectory() as directory:
        root = Path(directory)
        write_wav(root / "reference.wav", rate, reference)
        write_wav(root / "candidate.wav", rate, candidate)
        report = prepare(root / "reference.wav", root / "candidate.wav", root / "out")
        if abs(int(report["candidate_delay_samples"]) - delay) > 1:
            raise AssertionError(report)
        matched_rate, matched = read_wav(root / "out/candidate_aligned.wav")
        _, aligned = read_wav(root / "out/reference_aligned.wav")
        if matched_rate != rate or abs(rms(matched) - rms(aligned)) > 2e-4:
            raise AssertionError(report)
    print("PASS comparison alignment, level matching, WAV and report generation")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("reference", nargs="?", type=Path)
    parser.add_argument("candidate", nargs="?", type=Path)
    parser.add_argument("output", nargs="?", type=Path)
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()
    if args.self_test:
        self_test()
        return
    if args.reference is None or args.candidate is None or args.output is None:
        parser.error("reference candidate output が必要です")
    print(json.dumps(prepare(args.reference, args.candidate, args.output), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
