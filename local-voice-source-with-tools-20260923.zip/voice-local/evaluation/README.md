# 工程A：音質評価基盤

同じ発声から作った原音WAVと変換WAVを、遅延と音量を揃えて比較するための基盤です。女性声らしさや透明感を自動判定するものではありません。

## 入力

- PCM16 / mono WAV
- 原音と変換音は同じサンプルレート
- 同じ発話区間を含むこと

## 実行

```bash
python3 tools/prepare_comparison.py \
  original.wav converted.wav evaluation/result
```

`evaluation/result` に次を生成します。

- `reference_aligned.wav`：位置合わせ後の原音
- `candidate_aligned.wav`：位置合わせ・音量合わせ後の変換音
- `measurement.json`：推定遅延、音量補正、ピーク、クリップ数
- `rating.csv`：聴感評価の記入票

比較時は二つのWAVを同じ再生音量で聴きます。変換音の音量補正は比較用ファイルだけに適用され、アプリの出力設定は変更しません。

推定が不安定な場合は `measurement.json` の `correlation_confidence` が低くなります。その結果を品質判定に使わず、同じ発声から録り直します。

## 評価

`rating.csv` の4項目を1〜5で記録します。

- 女性声としての印象
- 透明感
- 自然さ
- 明瞭さ

コメントには、ダミ声、二重声、金属音、こもり、サ行、語頭・語尾など、気になった箇所を具体的に記録します。
