package jp.localvoice;

public final class LlvcBridgeTest {
    private static void check(boolean value,String message){if(!value)throw new AssertionError(message);}
    private static final class IdentityKernel implements LlvcKernel {
        int calls;
        @Override public int frameSize(){return LlvcStreamBridge.MODEL_FRAME;}
        @Override public void process(float[] input,float[] output){System.arraycopy(input,0,output,0,input.length);calls++;}
    }
    public static void main(String[] args){
        int cases=0;
        for(int deviceRate:new int[]{44100,48000}){
            StreamingResampler down=new StreamingResampler(deviceRate,16000);short[] input=new short[deviceRate];
            for(int i=0;i<input.length;i++)input[i]=(short)(12000*Math.sin(2*Math.PI*1000*i/deviceRate));
            float[] converted=new float[17000];int count=0;
            for(int offset=0;offset<input.length;offset+=480){
                int size=Math.min(480,input.length-offset);short[] part=new short[size];System.arraycopy(input,offset,part,0,size);
                down.push(part,size);count+=down.pull(converted,count,converted.length-count);
            }
            check(Math.abs(count-16000)<=2,"downsample length "+deviceRate+": "+count);
            double energy=0;for(int i=200;i<count;i++)energy+=converted[i]*converted[i];check(energy>100,"downsample signal");cases++;
            IdentityKernel kernel=new IdentityKernel();LlvcStreamBridge bridge=new LlvcStreamBridge(deviceRate,kernel);
            short[] block=new short[480],output=new short[480];long nonzero=0;
            for(int frame=0;frame<200;frame++){
                for(int i=0;i<block.length;i++)block[i]=(short)(9000*Math.sin(2*Math.PI*220*(frame*480L+i)/deviceRate));
                bridge.process(block,output,output.length,0,0,0,0,1,false);
                for(short sample:output)if(sample!=0)nonzero++;
            }
            check(kernel.calls>100,"kernel not framed");check(nonzero>deviceRate/2,"bridge output missing");cases++;
        }
        System.out.println("PASS "+cases+" LLVC bridge cases");
    }
}
