package jp.localvoice;
import java.io.*;
import java.nio.file.*;
import java.util.Arrays;

public final class WavTest {
    static void check(boolean test,String message){if(!test)throw new AssertionError(message);}
    static int le32(RandomAccessFile f)throws IOException{return Integer.reverseBytes(f.readInt());}
    public static void main(String[] args)throws Exception{
        File dir=Files.createTempDirectory("voice-wav-test").toFile();
        short[] samples={0,32767,-32768,1234,-5678};
        File target=new File(dir,"test.wav");
        try(WavFile wav=new WavFile(target,48000)){wav.write(samples,samples.length);}
        check(target.exists(),"committed WAV missing");check(!new File(target+".part").exists(),"partial remains");
        try(RandomAccessFile f=new RandomAccessFile(target,"r")){
            check(f.length()==54,"size");byte[] tag=new byte[4];f.readFully(tag);check(Arrays.equals(tag,"RIFF".getBytes()),"RIFF");
            check(le32(f)==46,"RIFF size");f.seek(24);check(le32(f)==48000,"rate");
            f.seek(40);check(le32(f)==10,"data size");for(short s:samples)check(Short.reverseBytes(f.readShort())==s,"PCM endian");
        }
        File part=new File(dir,"interrupted.wav.part");Files.copy(target.toPath(),part.toPath());
        try(RandomAccessFile f=new RandomAccessFile(part,"rw")){f.seek(40);f.writeInt(0);f.seek(f.length());f.write(7);}
        WavFile.recover(dir);
        File restored=new File(dir,"interrupted_recovered.wav");check(restored.exists(),"recovery");
        try(RandomAccessFile f=new RandomAccessFile(restored,"r")){check(f.length()==54,"odd-byte trimming");f.seek(40);check(le32(f)==10,"recovered size");}
        try(WavFile wav=new WavFile(new File(dir,"empty.wav"),44100)){wav.write(new short[0],0);}
        check(new File(dir,"empty.wav").length()==44,"empty WAV");
        File unknown=new File(dir,"unknown.wav.part");Files.write(unknown.toPath(),new byte[3]);WavFile.recover(dir);
        check(unknown.exists(),"invalid file should be preserved");
        System.out.println("PASS WAV: PCM/header, commit, recovery, odd-byte trimming, empty file, invalid-file preservation");
    }
}
