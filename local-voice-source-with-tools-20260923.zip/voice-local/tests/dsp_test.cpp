#include "../app/src/main/cpp/Processor.h"
#include <cassert>
#include <iostream>
#include <vector>
#include <random>

constexpr double PI=3.14159265358979323846;
std::vector<int16_t> sine(int sr,int count,double freq) {
    std::vector<int16_t> x(count);
    for(int i=0;i<count;i++)x[i]=static_cast<int16_t>(8000*std::sin(2*PI*freq*i/sr));
    return x;
}
double power(const std::vector<int16_t>& x,int sr,double frequency) {
    double re=0,im=0;int start=sr/2;
    for(int i=start;i<(int)x.size();i++){double p=2*PI*frequency*i/sr;re+=x[i]*std::cos(p);im+=x[i]*std::sin(p);}
    return re*re+im*im;
}
int main(){
    int cases=0;
    for(int sr:{44100,48000}) {
        auto input=sine(sr,sr*2,220);std::vector<int16_t> output(input.size());
        for(float shift:{-12.f,-5.f,0.f,5.f,12.f}){
            Processor p(sr);p.set(shift,0,0,0,false);
            for(int off=0;off<(int)input.size();off+=480)p.process(input.data()+off,output.data()+off,std::min(480,(int)input.size()-off));
            double expected=220*std::pow(2.,shift/12.);
            double best=0,frequency=0;
            for(double f=90;f<470;f+=0.5){double v=power(output,sr,f);if(v>best){best=v;frequency=f;}}
            std::cout<<"pitch "<<sr<<" "<<shift<<" expected="<<expected<<" peak="<<frequency<<"\n";
            assert(std::abs(frequency-expected)<8);cases++;
        }
        Processor silence(sr);std::vector<int16_t> zero(sr,0),silent(sr);
        silence.process(zero.data(),silent.data(),sr);for(auto y:silent)assert(y==0);cases++;
        Processor whole(sr),chunked(sr);whole.set(7,3,-0.5,0.2,true);chunked.set(7,3,-0.5,0.2,true);
        std::vector<int16_t> a(input.size()),b(input.size());whole.process(input.data(),a.data(),input.size());
        for(int off=0;off<(int)input.size();off+=127)chunked.process(input.data()+off,b.data()+off,std::min(127,(int)input.size()-off));
        assert(a==b);cases++;
        Processor stress(sr);std::mt19937 rng(17);std::uniform_int_distribution<int> dist(-32768,32767);
        std::array<int16_t,480> noise{},out{};
        for(int j=0;j<2000;j++){
            stress.set(j%25-12,12,(j%3)-1,j%2,j%2);
            for(auto& n:noise)n=dist(rng);
            stress.process(noise.data(),out.data(),480);
            for(auto v:out)assert(v>=-32735 && v<=32735);
        }cases++;
    }
    std::cout<<"PASS "<<cases<<" DSP cases\n";
}
