package jp.localvoice;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.*;
import android.view.View;
import android.widget.*;
import java.io.*;
import java.util.*;

/** Female-voice controls and recordings remain visible as two independent panels. */
public final class MainActivity extends Activity {
    private final Handler handler=new Handler(Looper.getMainLooper());
    private TextView state,time;
    private ProgressBar meter;
    private Button start,stop;
    private Switch monitor,original,gate;
    private SeekBar pitch,gain,tone;
    private LinearLayout recordings;
    private MediaPlayer player;
    private File exportFile;
    private boolean loading,lastBusy;
    private SharedPreferences prefs;
    private final Runnable tick=new Runnable(){public void run(){
        boolean busy=VoiceService.busy;AudioEngine e=VoiceService.engine;
        state.setText(busy && e!=null?e.status:VoiceService.message);start.setEnabled(!busy);stop.setEnabled(busy);
        if(e!=null){long s=e.frames/e.rate;time.setText(String.format(Locale.ROOT,"%02d:%02d · %dHz · underrun %d",s/60,s%60,e.rate,e.underruns));meter.setProgress((int)(e.peak*100));}
        if(lastBusy&&!busy)refreshRecordings();lastBusy=busy;handler.postDelayed(this,200);
    }};
    @Override public void onCreate(Bundle saved){
        super.onCreate(saved);prefs=getSharedPreferences("voice",MODE_PRIVATE);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14),dp(12),dp(14),dp(12));root.setBackgroundColor(Color.rgb(245,247,252));setContentView(root);
        LinearLayout controls=new LinearLayout(this);controls.setOrientation(LinearLayout.VERTICAL);root.addView(controls,new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,0,46));
        TextView title=label(controls,"ローカル変声",24);title.setTextColor(Color.rgb(30,44,80));
        state=label(controls,"待機中",16);time=label(controls,"00:00",12);
        meter=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);meter.setMax(100);controls.addView(meter);
        ScrollView controlScroll=new ScrollView(this);LinearLayout settings=new LinearLayout(this);settings.setOrientation(LinearLayout.VERTICAL);controlScroll.addView(settings);
        controls.addView(controlScroll,new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,0,1));
        loading=true;
        boolean femaleDefaults=!prefs.contains("female");
        pitch=slider(settings,"高さ",24,prefs.getInt("pitch",femaleDefaults?17:12),v->String.format(Locale.ROOT,"%+d",v-12));
        tone=slider(settings,"声質",200,prefs.getInt("tone",femaleDefaults?135:100),v->Integer.toString(v-100));
        gain=slider(settings,"出力",30,prefs.getInt("gain",18),v->(v-18)+"dB");
        gate=toggle(settings,"ノイズ低減",prefs.getBoolean("gate",true));monitor=toggle(settings,"イヤホン確認",false);original=toggle(settings,"比較用原音を保存",prefs.getBoolean("original",false));
        loading=false;
        LinearLayout presets=new LinearLayout(this);settings.addView(presets);
        preset(presets,"柔らか",4,15);preset(presets,"クリア",5,35);preset(presets,"明るめ",6,50);
        button(settings,"調声",v->{if(VoiceService.busy){toast("録音停止後に調声");return;}stopPlayer();startActivity(new Intent(this,TuningActivity.class));});
        LinearLayout actions=new LinearLayout(this);actions.setOrientation(LinearLayout.HORIZONTAL);controls.addView(actions);
        start=button(actions,"● 録音開始",v->begin());stop=button(actions,"■ 停止・保存",v->{if(VoiceService.busy)startService(new Intent(this,VoiceService.class).setAction("STOP"));});
        View divider=new View(this);divider.setBackgroundColor(Color.rgb(205,211,224));root.addView(divider,new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,dp(1)));
        LinearLayout files=new LinearLayout(this);files.setOrientation(LinearLayout.VERTICAL);files.setPadding(0,dp(5),0,0);root.addView(files,new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,0,54));
        LinearLayout fileHeader=new LinearLayout(this);fileHeader.setOrientation(LinearLayout.HORIZONTAL);files.addView(fileHeader);
        TextView fileTitle=label(fileHeader,"録音",18);fileTitle.setTextColor(Color.rgb(30,44,80));button(fileHeader,"再生停止",v->stopPlayer());
        ScrollView recordingScroll=new ScrollView(this);recordings=new LinearLayout(this);recordings.setOrientation(LinearLayout.VERTICAL);recordingScroll.addView(recordings);files.addView(recordingScroll,new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,0,1));
        if(VoiceService.busy){Settings s=VoiceService.settings;loading=true;pitch.setProgress((int)s.pitch+12);tone.setProgress((int)(s.tone*100)+100);gain.setProgress((int)s.gain+18);gate.setChecked(s.gate);monitor.setChecked(s.monitor);original.setChecked(s.original);loading=false;}else publish();
        WavFile.recover(VoiceService.directory(this));refreshRecordings();
    }
    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+0.5f);}
    private TextView label(LinearLayout box,String text,int size){TextView t=new TextView(this);t.setText(text);t.setTextSize(size);t.setPadding(0,dp(5),0,dp(3));box.addView(t);return t;}
    private Button button(LinearLayout box,String text,View.OnClickListener click){Button b=new Button(this);b.setText(text);if(box.getOrientation()==LinearLayout.HORIZONTAL){b.setTextSize(12);box.addView(b,new LinearLayout.LayoutParams(0,LinearLayout.LayoutParams.WRAP_CONTENT,1));}else box.addView(b);b.setOnClickListener(click);return b;}
    private interface Format{String text(int value);}
    private SeekBar slider(LinearLayout box,String title,int max,int initial,Format format){TextView t=label(box,title+": "+format.text(initial),14);SeekBar b=new SeekBar(this);b.setMax(max);b.setProgress(initial);box.addView(b);b.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar x,int n,boolean u){t.setText(title+": "+format.text(n));publish();}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}});return b;}
    private Switch toggle(LinearLayout box,String text,boolean value){Switch s=new Switch(this);s.setText(text);s.setChecked(value);box.addView(s);s.setOnCheckedChangeListener((b,on)->publish());return s;}
    private void preset(LinearLayout box,String name,int p,int t){button(box,name,v->{loading=true;pitch.setProgress(p+12);tone.setProgress(t+100);gain.setProgress(18);loading=false;publish();});}
    private void publish(){if(loading||original==null)return;VoiceService.settings=new Settings(pitch.getProgress()-12,gain.getProgress()-18,(tone.getProgress()-100)/100f,0,1,gate.isChecked(),monitor.isChecked(),original.isChecked());prefs.edit().putInt("pitch",pitch.getProgress()).putInt("gain",gain.getProgress()).putInt("tone",tone.getProgress()).putInt("robot",0).putInt("female",100).putBoolean("gate",gate.isChecked()).putBoolean("original",original.isChecked()).apply();}
    private void begin(){if(VoiceService.busy)return;if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},10);return;}if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED&&!prefs.getBoolean("notificationAsked",false)){prefs.edit().putBoolean("notificationAsked",true).apply();requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},11);return;}publish();start.setEnabled(false);try{startForegroundService(new Intent(this,VoiceService.class).setAction("START"));}catch(RuntimeException ex){toast("開始失敗: "+ex.getMessage());start.setEnabled(true);}}
    @Override public void onRequestPermissionsResult(int code,String[] p,int[] r){super.onRequestPermissionsResult(code,p,r);if(code==10&&(r.length==0||r[0]!=PackageManager.PERMISSION_GRANTED)){toast("マイク許可が必要です");return;}if(code==10||code==11)begin();}
    private void refreshRecordings(){if(recordings==null||isDestroyed())return;recordings.removeAllViews();File[] files=VoiceService.directory(this).listFiles((d,n)->n.endsWith(".wav"));if(files==null||files.length==0){label(recordings,"録音なし",14);return;}Arrays.sort(files,(a,b)->Long.compare(b.lastModified(),a.lastModified()));int page=30;for(int i=0;i<Math.min(files.length,page);i++)addRecording(files[i]);if(files.length>page)button(recordings,"残り"+(files.length-page)+"件",v->{v.setVisibility(View.GONE);for(int i=page;i<files.length;i++)addRecording(files[i]);});}
    private void addRecording(File file){label(recordings,file.getName()+String.format(Locale.ROOT,"  %.1fMB",file.length()/1048576.0),12);LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);recordings.addView(row);button(row,"再生",v->play(file));button(row,"書出",v->export(file));button(row,"削除",v->new AlertDialog.Builder(this).setTitle("削除しますか？").setMessage(file.getName()).setNegativeButton("戻る",null).setPositiveButton("削除",(d,w)->{stopPlayer();toast(file.delete()?"削除しました":"削除失敗");refreshRecordings();}).show());}
    private void play(File file){if(VoiceService.busy){toast("録音停止後に再生");return;}stopPlayer();try{player=new MediaPlayer();player.setDataSource(file.getPath());player.setOnCompletionListener(p->stopPlayer());player.setOnErrorListener((p,a,b)->{stopPlayer();toast("再生失敗");return true;});player.prepare();player.start();}catch(IOException|RuntimeException ex){stopPlayer();toast("再生失敗");}}
    private void export(File file){exportFile=file;Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT).setType("audio/wav").addCategory(Intent.CATEGORY_OPENABLE).putExtra(Intent.EXTRA_TITLE,file.getName());startActivityForResult(i,20);}
    @Override protected void onActivityResult(int req,int result,Intent data){super.onActivityResult(req,result,data);if(req!=20||result!=RESULT_OK||data==null||exportFile==null)return;File source=exportFile;Uri target=data.getData();exportFile=null;if(target==null)return;new Thread(()->{try(InputStream in=new FileInputStream(source);OutputStream out=getContentResolver().openOutputStream(target,"w")){if(out==null)throw new IOException("出力先を開けません");byte[] buf=new byte[65536];int n;while((n=in.read(buf))!=-1)out.write(buf,0,n);out.flush();runOnUiThread(()->toast("書き出しました"));}catch(IOException ex){runOnUiThread(()->toast("書出失敗"));}},"ExportWav").start();}
    private void stopPlayer(){if(player!=null){player.release();player=null;}}
    private void toast(String text){Toast.makeText(this,text,Toast.LENGTH_LONG).show();}
    @Override protected void onResume(){super.onResume();handler.post(tick);refreshRecordings();}
    @Override protected void onPause(){handler.removeCallbacks(tick);stopPlayer();super.onPause();}
}
