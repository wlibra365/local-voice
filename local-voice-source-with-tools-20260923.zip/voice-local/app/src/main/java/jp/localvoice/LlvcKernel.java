package jp.localvoice;

/** Runtime-neutral boundary for one stateful LLVC frame. */
interface LlvcKernel {
    int frameSize();
    void process(float[] input,float[] output);
}
