package jp.localvoice;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Arrays;
import java.util.Locale;

/** File screen only: list, playback, export and deletion. */
public final class RecordingsActivity extends Activity {
    private LinearLayout recordings;
    private MediaPlayer player;
    private File exportFile;

    @Override public void onCreate(Bundle saved){
        super.onCreate(saved);
        ScrollView scroll=new ScrollView(this);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22),dp(28),dp(22),dp(24));scroll.addView(root);setContentView(scroll);
        label(root,"録音ファイル",28);label(root,"再生・書き出し・削除",16);
        button(root,"変声画面へ戻る",v->finish());
        button(root,"再生を停止",v->stopPlayer());
        recordings=new LinearLayout(this);recordings.setOrientation(LinearLayout.VERTICAL);root.addView(recordings);
        label(root,"録音中は再生できません。削除は元に戻せないため、必要なら先に書き出してください。",13);
        WavFile.recover(VoiceService.directory(this));refreshRecordings();
    }
    private int dp(int value){return (int)(value*getResources().getDisplayMetrics().density+0.5f);}
    private TextView label(LinearLayout box,String value,int size){
        TextView text=new TextView(this);text.setText(value);text.setTextSize(size);text.setPadding(0,dp(8),0,dp(6));box.addView(text);return text;
    }
    private Button button(LinearLayout box,String text,View.OnClickListener click){
        Button result=new Button(this);result.setText(text);
        if(box.getOrientation()==LinearLayout.HORIZONTAL){
            result.setTextSize(12);box.addView(result,new LinearLayout.LayoutParams(0,LinearLayout.LayoutParams.WRAP_CONTENT,1));
        }else box.addView(result);
        result.setOnClickListener(click);return result;
    }
    private void refreshRecordings(){
        recordings.removeAllViews();
        File[] files=VoiceService.directory(this).listFiles((dir,name)->name.endsWith(".wav"));
        if(files==null || files.length==0){label(recordings,"録音ファイルはありません",16);return;}
        Arrays.sort(files,(a,b)->Long.compare(b.lastModified(),a.lastModified()));
        int pageSize=30;
        for(int i=0;i<Math.min(files.length,pageSize);i++)addRecording(files[i]);
        if(files.length>pageSize)button(recordings,"残り "+(files.length-pageSize)+" 件を表示",v->{
            v.setVisibility(View.GONE);for(int i=pageSize;i<files.length;i++)addRecording(files[i]);
        });
    }
    private void addRecording(File file){
        label(recordings,file.getName()+String.format(Locale.ROOT,"\n%.1f MB",file.length()/1048576.0),13);
        LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);recordings.addView(row);
        button(row,"再生",v->play(file));
        button(row,"書出",v->export(file));
        button(row,"削除",v->new AlertDialog.Builder(this).setTitle("録音を削除しますか？")
            .setMessage(file.getName()+"\n元に戻せません。必要なら先に書き出してください。")
            .setNegativeButton("戻る",null).setPositiveButton("削除",(d,w)->{
                stopPlayer();toast(file.delete()?"削除しました":"削除できませんでした");refreshRecordings();
            }).show());
    }
    private void play(File file){
        if(VoiceService.busy){toast("録音を停止してから再生してください");return;}
        stopPlayer();
        try{player=new MediaPlayer();player.setDataSource(file.getPath());
            player.setOnCompletionListener(p->stopPlayer());
            player.setOnErrorListener((p,a,b)->{stopPlayer();toast("再生できません");return true;});
            player.prepare();player.start();
        }catch(IOException | RuntimeException ex){stopPlayer();toast("再生エラー: "+ex.getMessage());}
    }
    private void export(File file){
        exportFile=file;
        Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT).setType("audio/wav")
            .addCategory(Intent.CATEGORY_OPENABLE).putExtra(Intent.EXTRA_TITLE,file.getName());
        startActivityForResult(intent,20);
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(request!=20 || result!=RESULT_OK || data==null || exportFile==null)return;
        File source=exportFile;Uri target=data.getData();exportFile=null;if(target==null)return;
        new Thread(()->{
            try(InputStream in=new FileInputStream(source);OutputStream out=getContentResolver().openOutputStream(target,"w")){
                if(out==null)throw new IOException("出力先を開けません");
                byte[] buffer=new byte[65536];int n;while((n=in.read(buffer))!=-1)out.write(buffer,0,n);out.flush();
                runOnUiThread(()->toast("書き出しました"));
            }catch(IOException ex){runOnUiThread(()->toast("書出失敗。元の録音は保持されています: "+ex.getMessage()));}
        },"ExportWav").start();
    }
    private void stopPlayer(){if(player!=null){player.release();player=null;}}
    private void toast(String text){android.widget.Toast.makeText(this,text,android.widget.Toast.LENGTH_LONG).show();}
    @Override protected void onResume(){super.onResume();if(recordings!=null)refreshRecordings();}
    @Override protected void onPause(){stopPlayer();super.onPause();}
}
