package jp.localvoice;

/**
 * Frames device-rate PCM into the official LLVC 16 kHz / 208-sample stream.
 * A concrete mobile runtime supplies the kernel; this bridge never selects a
 * placeholder model and therefore is not enabled by the factory yet.
 */
final class LlvcStreamBridge implements VoiceProcessor {
    static final int MODEL_RATE=16000, MODEL_FRAME=208;
    private final LlvcKernel kernel;
    private final StreamingResampler down,up;
    private final float[] modelInput,modelOutput,scratch=new float[1024];
    private int modelFill;

    LlvcStreamBridge(int deviceRate,LlvcKernel kernel){
        if(deviceRate!=44100&&deviceRate!=48000)throw new IllegalArgumentException("device rate");
        if(kernel==null||kernel.frameSize()!=MODEL_FRAME)throw new IllegalArgumentException("LLVC frame");
        this.kernel=kernel;down=new StreamingResampler(deviceRate,MODEL_RATE);up=new StreamingResampler(MODEL_RATE,deviceRate);
        modelInput=new float[MODEL_FRAME];modelOutput=new float[MODEL_FRAME];
    }
    @Override public String engineId(){return "llvc";}
    @Override public void process(short[] input,short[] output,int count,float semitones,float decibels,
        float color,float metallic,float feminine,boolean noiseGate){
        if(count<0||count>input.length||count>output.length)throw new IllegalArgumentException("count");
        down.push(input,count);
        while(true){
            int got=down.pull(modelInput,modelFill,MODEL_FRAME-modelFill);modelFill+=got;
            if(modelFill<MODEL_FRAME)break;
            kernel.process(modelInput,modelOutput);up.push(modelOutput,MODEL_FRAME);modelFill=0;
        }
        float gain=(float)Math.pow(10,Math.max(-18,Math.min(12,decibels))/20.0);int produced=0;
        while(produced<count){
            int wanted=Math.min(scratch.length,count-produced);int got=up.pull(scratch,0,wanted);
            for(int i=0;i<got;i++)output[produced+i]=pcm(scratch[i]*gain);
            produced+=got;if(got<wanted)break;
        }
        while(produced<count)output[produced++]=0;
    }
    private static short pcm(float value){
        int sample=Math.round(value*32768);if(sample>32735)sample=32735;if(sample<-32735)sample=-32735;return (short)sample;
    }
}
