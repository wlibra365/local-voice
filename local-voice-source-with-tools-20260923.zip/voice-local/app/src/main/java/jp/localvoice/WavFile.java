package jp.localvoice;
import java.io.*;

/** Partial recordings remain recoverable; commit renames only after header sync. */
final class WavFile implements AutoCloseable {
    private final RandomAccessFile out;
    private final File partial, target;
    private final int rate;
    private long bytes;
    private final byte[] buffer = new byte[2048];
    WavFile(File target, int rate) throws IOException {
        this.target=target; this.rate=rate;
        partial=new File(target.getPath()+".part");
        out=new RandomAccessFile(partial,"rw");
        out.setLength(0); header(out,0,rate);
    }
    private static void le16(RandomAccessFile f,int v) throws IOException { f.write(v); f.write(v>>>8); }
    private static void le32(RandomAccessFile f,long v) throws IOException {
        f.write((int)v); f.write((int)(v>>>8)); f.write((int)(v>>>16)); f.write((int)(v>>>24));
    }
    private static void header(RandomAccessFile f,long n,int rate) throws IOException {
        f.seek(0); f.writeBytes("RIFF"); le32(f,36+n); f.writeBytes("WAVEfmt ");
        le32(f,16); le16(f,1); le16(f,1); le32(f,rate); le32(f,rate*2L);
        le16(f,2); le16(f,16); f.writeBytes("data"); le32(f,n);
    }
    void write(short[] samples,int count) throws IOException {
        if (count*2>buffer.length) throw new IOException("音声ブロック超過");
        if (bytes+count*2L > 0xfffffff0L-44) throw new IOException("WAV容量上限");
        for(int i=0;i<count;i++){ buffer[i*2]=(byte)samples[i]; buffer[i*2+1]=(byte)(samples[i]>>>8); }
        out.write(buffer,0,count*2); bytes+=count*2L;
    }
    public void close() throws IOException {
        try { header(out,bytes,rate); out.getFD().sync(); } finally { out.close(); }
        if (!partial.renameTo(target)) throw new IOException("録音確定に失敗。partファイルを保持しました");
    }
    static void recover(File directory) {
        File[] files=directory.listFiles((d,n)->n.endsWith(".wav.part"));
        if(files==null)return;
        for(File file:files) {
            try(RandomAccessFile f=new RandomAccessFile(file,"rw")) {
                if(f.length()<44)continue;
                f.seek(24); int rate=Integer.reverseBytes(f.readInt());
                if(rate!=44100 && rate!=48000)continue;
                long n=(f.length()-44)&~1L; f.setLength(n+44); header(f,n,rate); f.getFD().sync();
            } catch(IOException ex) { continue; }
            File target=new File(file.getPath().replace(".wav.part","_recovered.wav"));
            if(!target.exists()) file.renameTo(target);
        }
    }
}
