package jp.localvoice;
final class Settings {
    final float pitch, gain, tone, robot, female;
    final boolean gate, monitor, original;
    Settings(float p, float g, float t, float r, float f, boolean n, boolean m, boolean o) {
        pitch=p; gain=g; tone=t; robot=r; female=f; gate=n; monitor=m; original=o;
    }
}
