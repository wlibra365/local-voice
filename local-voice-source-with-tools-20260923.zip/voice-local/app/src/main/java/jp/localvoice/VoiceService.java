package jp.localvoice;

import android.app.*;
import android.content.*;
import android.content.pm.ServiceInfo;
import android.media.*;
import android.os.*;
import java.io.File;

public final class VoiceService extends Service {
    static volatile Settings settings=new Settings(0,0,0,0,1,true,false,false);
    static volatile AudioEngine engine;
    static volatile boolean busy;
    static volatile String message="待機中";
    private PowerManager.WakeLock wake;
    private AudioManager audio;
    private AudioFocusRequest focus;
    private boolean focused;
    private final BroadcastReceiver noisy=new BroadcastReceiver(){
        @Override public void onReceive(Context c,Intent i){if(engine!=null)engine.stop();}
    };
    @Override public void onCreate(){
        super.onCreate();
        IntentFilter filter=new IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY);
        if(Build.VERSION.SDK_INT>=33)registerReceiver(noisy,filter,Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(noisy,filter);
    }
    static File directory(Context c){return new File(c.getFilesDir(),"recordings");}
    @Override public IBinder onBind(Intent i){return null;}
    @Override public int onStartCommand(Intent intent,int flags,int id) {
        if(intent==null){stopSelf();return START_NOT_STICKY;}
        if("STOP".equals(intent.getAction())){if(engine!=null)engine.stop();else stopSelf();return START_NOT_STICKY;}
        if(busy)return START_NOT_STICKY;
        busy=true;message="準備中";
        try {
            NotificationManager nm=getSystemService(NotificationManager.class);
            nm.createNotificationChannel(new NotificationChannel("recording","変声・録音",NotificationManager.IMPORTANCE_LOW));
            PendingIntent open=PendingIntent.getActivity(this,0,new Intent(this,MainActivity.class),PendingIntent.FLAG_IMMUTABLE);
            PendingIntent stop=PendingIntent.getService(this,1,new Intent(this,VoiceService.class).setAction("STOP"),PendingIntent.FLAG_IMMUTABLE);
            Notification note=new Notification.Builder(this,"recording")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now).setContentTitle("ローカル変声・録音中")
                .setContentText("音声は端末内に保存されます").setOngoing(true).setContentIntent(open)
                .addAction(new Notification.Action.Builder(null,"停止して保存",stop).build()).build();
            if(Build.VERSION.SDK_INT>=29)startForeground(1,note,ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
            else startForeground(1,note);
            audio=getSystemService(AudioManager.class);
            focus=new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
                .setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                .setOnAudioFocusChangeListener(change->{
                    if(change<0 && engine!=null){message="他の音声処理により停止";engine.stop();}
                }).build();
            focused=audio.requestAudioFocus(focus)==AudioManager.AUDIOFOCUS_REQUEST_GRANTED;
            if(!focused)throw new IllegalStateException("他の音声利用が終了してから開始してください");
            wake=getSystemService(PowerManager.class).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"localvoice:recording");
            wake.acquire(2*60*60*1000L+60000);
            engine=new AudioEngine(getApplicationContext(),directory(this),settings.original,
                ()->new Handler(Looper.getMainLooper()).post(()->{
                    if(engine!=null)message=engine.status;
                    busy=false;stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();
                }));
            new Thread(engine,"VoiceAudio").start();
        }catch(RuntimeException ex){message="開始できません: "+ex.getMessage();busy=false;stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();}
        return START_NOT_STICKY;
    }
    @Override public void onDestroy(){
        unregisterReceiver(noisy);
        if(engine!=null && engine.active)engine.stop();
        if(wake!=null && wake.isHeld())wake.release();
        if(audio!=null && focus!=null && focused)audio.abandonAudioFocusRequest(focus);
        super.onDestroy();
    }
}
