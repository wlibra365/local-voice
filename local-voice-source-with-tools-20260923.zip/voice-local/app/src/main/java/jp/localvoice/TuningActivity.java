package jp.localvoice;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.*;
import android.os.*;
import android.view.View;
import android.widget.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

/** Dedicated capture, transform and return-playback screen. */
public final class TuningActivity extends Activity {
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final AtomicInteger renderGeneration=new AtomicInteger();
    private SharedPreferences prefs;
    private TextView state,pitchLabel,toneLabel;
    private SeekBar pitch,tone;
    private Button capture,play,baseline,apply;
    private volatile boolean capturing;
    private volatile AudioRecord recorder;
    private AudioTrack player;
    private short[] dry,latestWet,entryWet;
    private int sampleRate=48000,entryPitch,entryTone;
    private boolean changed,autoPlay=true;

    @Override public void onCreate(Bundle saved){
        super.onCreate(saved);prefs=getSharedPreferences("voice",MODE_PRIVATE);
        entryPitch=prefs.getInt("pitch",17);entryTone=prefs.getInt("tone",135);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18),dp(22),dp(18),dp(18));root.setBackgroundColor(Color.rgb(245,247,252));
        setContentView(root);
        label(root,"調声",26);state=label(root,"「声を入れる」で短く発声",16);
        pitchLabel=label(root,"高さ: "+signed(entryPitch-12),15);
        pitch=new SeekBar(this);pitch.setMax(24);pitch.setProgress(entryPitch);root.addView(pitch);
        toneLabel=label(root,"声質: "+toneName(entryTone),15);
        tone=new SeekBar(this);tone.setMax(200);tone.setProgress(entryTone);root.addView(tone);
        capture=button(root,"声を入れる",v->toggleCapture());
        LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);root.addView(row);
        play=button(row,"再生",v->playLatest());baseline=button(row,"入場時と比較",v->playBaseline());
        apply=button(root,"適用して戻る",v->applyAndFinish());button(root,"戻る",v->leave());
        setSampleControls(false);
        SeekBar.OnSeekBarChangeListener listener=new SeekBar.OnSeekBarChangeListener(){
            public void onProgressChanged(SeekBar b,int value,boolean user){
                pitchLabel.setText("高さ: "+signed(pitch.getProgress()-12));
                toneLabel.setText("声質: "+toneName(tone.getProgress()));
                if(user)changed=pitch.getProgress()!=entryPitch||tone.getProgress()!=entryTone;
            }
            public void onStartTrackingTouch(SeekBar b){autoPlay=true;stopPlayback();}
            public void onStopTrackingTouch(SeekBar b){if(dry!=null)render(false,true);}
        };
        pitch.setOnSeekBarChangeListener(listener);tone.setOnSeekBarChangeListener(listener);
    }
    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+0.5f);}
    private TextView label(LinearLayout box,String text,int size){TextView t=new TextView(this);t.setText(text);t.setTextSize(size);t.setPadding(0,dp(7),0,dp(5));box.addView(t);return t;}
    private Button button(LinearLayout box,String text,View.OnClickListener click){Button b=new Button(this);b.setText(text);if(box.getOrientation()==LinearLayout.HORIZONTAL)box.addView(b,new LinearLayout.LayoutParams(0,LinearLayout.LayoutParams.WRAP_CONTENT,1));else box.addView(b);b.setOnClickListener(click);return b;}
    private static String signed(int value){return String.format(Locale.ROOT,"%+d",value);}
    private static String toneName(int value){if(value<70)return "柔らかい "+(value-100);if(value>130)return "澄んだ +"+(value-100);return "自然 "+signed(value-100);}
    private void setSampleControls(boolean enabled){play.setEnabled(enabled);baseline.setEnabled(enabled);apply.setEnabled(enabled);pitch.setEnabled(!capturing);tone.setEnabled(!capturing);}
    private void toggleCapture(){if(capturing){capturing=false;return;}if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},30);return;}beginCapture();}
    @Override public void onRequestPermissionsResult(int code,String[] p,int[] r){super.onRequestPermissionsResult(code,p,r);if(code==30&&r.length>0&&r[0]==PackageManager.PERMISSION_GRANTED)beginCapture();else if(code==30)state.setText("マイク許可が必要です");}
    private AudioRecord openRecorder(int rate){
        int minimum=AudioRecord.getMinBufferSize(rate,AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_16BIT);
        if(minimum<=0)throw new IllegalStateException("入力形式未対応");
        AudioRecord result=new AudioRecord.Builder().setAudioSource(MediaRecorder.AudioSource.VOICE_RECOGNITION)
            .setAudioFormat(new AudioFormat.Builder().setSampleRate(rate).setChannelMask(AudioFormat.CHANNEL_IN_MONO).setEncoding(AudioFormat.ENCODING_PCM_16BIT).build())
            .setBufferSizeInBytes(Math.max(minimum,3840)).build();
        if(result.getState()!=AudioRecord.STATE_INITIALIZED){result.release();throw new IllegalStateException("マイク初期化失敗");}
        return result;
    }
    private void beginCapture(){
        if(VoiceService.busy){state.setText("通常録音を停止してから調声");return;}
        stopPlayback();renderGeneration.incrementAndGet();capturing=true;capture.setText("収録停止");setSampleControls(false);state.setText("声を待っています…");
        new Thread(this::captureLoop,"TuningCapture").start();
    }
    private void captureLoop(){
        AudioRecord local=null;
        try{
            try{local=openRecorder(48000);sampleRate=48000;}catch(RuntimeException ex){sampleRate=44100;local=openRecorder(sampleRate);}
            recorder=local;short[] block=new short[480];short[] all=new short[sampleRate*13];int total=0,start=-1,quiet=0,voiceAt=-1;
            local.startRecording();
            while(capturing&&total<all.length){
                int n=local.read(block,0,block.length,AudioRecord.READ_BLOCKING);if(n<=0)throw new IllegalStateException("マイク読込エラー");
                int copy=Math.min(n,all.length-total);System.arraycopy(block,0,all,total,copy);float peak=0;
                for(int i=0;i<copy;i++)peak=Math.max(peak,Math.abs((int)block[i])/32768f);
                total+=copy;
                if(peak>=0.018f){if(start<0){start=Math.max(0,total-copy-sampleRate/5);voiceAt=total-copy;handler.post(()->state.setText("発声を収録中…"));}quiet=0;}
                else if(start>=0)quiet+=copy;
                if(start<0&&total>=sampleRate*5)break;
                if(start>=0&&(quiet>=sampleRate*8/10||total-voiceAt>=sampleRate*8))break;
            }
            capturing=false;
            if(start<0){handler.post(()->finishCapture(null,"声が入りませんでした"));return;}
            int end=Math.min(total,start+sampleRate*8);short[] sample=Arrays.copyOfRange(all,start,end);
            handler.post(()->finishCapture(sample,null));
        }catch(RuntimeException ex){String message=ex.getMessage();handler.post(()->finishCapture(null,"収録失敗: "+message));}
        finally{capturing=false;recorder=null;if(local!=null){try{local.stop();}catch(IllegalStateException ignored){}local.release();}}
    }
    private void finishCapture(short[] sample,String error){
        capture.setText(sample==null&&dry==null?"声を入れる":"録り直す");pitch.setEnabled(true);tone.setEnabled(true);
        if(sample==null){state.setText(error);setSampleControls(dry!=null);return;}
        dry=sample;entryWet=null;latestWet=null;autoPlay=true;state.setText("変換中…");render(true,true);
    }
    private void render(boolean alsoEntry,boolean playWhenReady){
        if(dry==null)return;int token=renderGeneration.incrementAndGet();short[] source=dry.clone();int rate=sampleRate;
        int p=pitch.getProgress()-12;float t=(tone.getProgress()-100)/100f;
        new Thread(()->{
            if(alsoEntry){short[] base=convert(source,rate,entryPitch-12,(entryTone-100)/100f);if(token!=renderGeneration.get())return;entryWet=base;}
            short[] wet=convert(source,rate,p,t);if(token!=renderGeneration.get())return;latestWet=wet;
            handler.post(()->{if(token!=renderGeneration.get())return;state.setText("調整できます");setSampleControls(true);if(playWhenReady&&autoPlay)startPlayback(wet);});
        },"TuningRender").start();
    }
    private short[] convert(short[] source,int rate,float p,float t){
        VoiceProcessor processor=VoiceProcessorFactory.createBaseline(rate);int tail=rate/5;short[] result=new short[source.length+tail];short[] in=new short[480],out=new short[480];
        for(int offset=0;offset<result.length;offset+=480){int n=Math.min(480,result.length-offset);Arrays.fill(in,(short)0);if(offset<source.length)System.arraycopy(source,offset,in,0,Math.min(n,source.length-offset));processor.process(in,out,n,p,0,t,0,1,false);System.arraycopy(out,0,result,offset,n);}
        return result;
    }
    private void playLatest(){autoPlay=false;if(latestWet==null)render(false,true);else startPlayback(latestWet);}
    private void playBaseline(){autoPlay=false;if(entryWet==null)render(true,false);else startPlayback(entryWet);}
    private void startPlayback(short[] audio){
        stopPlayback();try{player=new AudioTrack.Builder().setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(new AudioFormat.Builder().setSampleRate(sampleRate).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).setEncoding(AudioFormat.ENCODING_PCM_16BIT).build())
            .setBufferSizeInBytes(audio.length*2).setTransferMode(AudioTrack.MODE_STATIC).build();player.write(audio,0,audio.length);player.play();state.setText("再生中");
            AudioTrack expected=player;handler.postDelayed(()->{if(player==expected){stopPlayback();state.setText("調整できます");}},audio.length*1000L/sampleRate+150);
        }catch(RuntimeException ex){stopPlayback();state.setText("再生失敗");}
    }
    private void stopPlayback(){if(player!=null){try{player.stop();}catch(IllegalStateException ignored){}player.release();player=null;}}
    private void applyAndFinish(){
        int p=pitch.getProgress(),t=tone.getProgress();prefs.edit().putInt("pitch",p).putInt("tone",t).apply();Settings s=VoiceService.settings;
        VoiceService.settings=new Settings(p-12,s.gain,(t-100)/100f,0,1,s.gate,false,s.original);changed=false;finish();
    }
    private void leave(){if(!changed){finish();return;}new AlertDialog.Builder(this).setTitle("調整をどうしますか？").setPositiveButton("適用",(d,w)->applyAndFinish()).setNegativeButton("破棄",(d,w)->{changed=false;finish();}).setNeutralButton("続ける",null).show();}
    @SuppressWarnings("deprecation") @Override public void onBackPressed(){leave();}
    @Override protected void onPause(){capturing=false;AudioRecord r=recorder;if(r!=null)try{r.stop();}catch(IllegalStateException ignored){}stopPlayback();renderGeneration.incrementAndGet();super.onPause();}
    @Override protected void onDestroy(){dry=null;latestWet=null;entryWet=null;super.onDestroy();}
}
