package jp.localvoice;

/** Central construction point. Candidate engines enter here after quality validation. */
final class VoiceProcessorFactory {
    private VoiceProcessorFactory(){}
    static VoiceProcessor createBaseline(int sampleRate){
        return Dsp.create(sampleRate);
    }
}
