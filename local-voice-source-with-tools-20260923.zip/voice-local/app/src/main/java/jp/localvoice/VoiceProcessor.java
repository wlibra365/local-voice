package jp.localvoice;

/** Block voice processor boundary used to replace the legacy DSP safely. */
interface VoiceProcessor {
    String engineId();
    void process(short[] input,short[] output,int count,float semitones,float decibels,
        float color,float metallic,float feminine,boolean noiseGate);
}
