#include <jni.h>
#include "Processor.h"
extern "C" JNIEXPORT jlong JNICALL
Java_jp_localvoice_Dsp_create(JNIEnv*, jclass, jint rate) {
    if (rate != 48000 && rate != 44100) return 0;
    return reinterpret_cast<jlong>(new Processor(static_cast<float>(rate)));
}
extern "C" JNIEXPORT void JNICALL
Java_jp_localvoice_Dsp_destroy(JNIEnv*, jclass, jlong handle) { delete reinterpret_cast<Processor*>(handle); }
extern "C" JNIEXPORT void JNICALL
Java_jp_localvoice_Dsp_process(JNIEnv* env, jclass, jlong handle, jshortArray input,
    jshortArray output, jint count, jfloat pitch, jfloat gain, jfloat tone, jfloat robot, jboolean gate) {
    if (!handle || count < 0 || count > env->GetArrayLength(input) || count > env->GetArrayLength(output)) return;
    auto* in = env->GetShortArrayElements(input, nullptr); if (!in) return;
    auto* out = env->GetShortArrayElements(output, nullptr);
    if (!out) { env->ReleaseShortArrayElements(input, in, JNI_ABORT); return; }
    auto* p = reinterpret_cast<Processor*>(handle);
    p->set(pitch, gain, tone, robot, gate);
    p->process(in, out, count);
    env->ReleaseShortArrayElements(input, in, JNI_ABORT);
    env->ReleaseShortArrayElements(output, out, 0);
}
