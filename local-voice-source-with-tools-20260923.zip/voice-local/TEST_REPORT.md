# 検証結果 — 2026-09-22

## 結論

DSP・WAVの単体テスト、Java構文解析、Android APKの生成・署名・zipalign・内容検査は成功。
**Android APIの実機動作、画面表示、実マイク録音、音質・遅延は未検証。**
APKはデバッグ署名であり、公開用リリース署名ではない。
APK SHA-256: `dd68bd3fe84cfeed7858367a2708fdb28fbea2f424411b0e02bfaa461c1ee839`

## 実行環境とコマンド

Linux / OpenJDK 17.0.20 / Android SDK command-line tools 12.0 / build-tools 35.0.0。
JDKにはjavac実行ファイルがないが、jdk.compilerモジュールが利用できたため `java com.sun.tools.javac.Main` でテストとAPKのJavaコンパイルを行った。

```bash
bash tests/run.sh
ANDROID_SDK_ROOT=/path/to/android-sdk ./build-apk.sh
```

最終実行：終了コード0。

## 自動テスト

| 対象 | 結果 | 検証内容 |
|---|---|---|
| Java DSP | PASS 16ケース | 44.1/48kHz、±12/±5/0半音、無音、ブロック分割、設定変更・出力範囲 |
| WAV実ファイルテスト | PASS | ヘッダ・PCMエンディアン、確定、復旧、奇数バイト切捨、空録音、破損ファイル保持 |
| Java構文解析 | PASS 14ソース | 構文のみ。Android依存型の解決はしない |
| LLVC接続ブリッジ | PASS 4ケース | 44.1/48kHz→16kHz、208サンプルフレーム、出力復帰 |
| 比較・モデル検証 | PASS | 遅延・音量合わせ、モデルハッシュ・形式・状態・フレーム長・ライセンス存在検査 |
| APK内容 | PASS | aapt2リンク、D8 dex生成、v2/v3署名、zipalign、aapt2/apkanalyzer/unzip検査 |

Java DSPはJDKの境界チェックとテスト入力で検証した。Android実行時のGC・負荷・音切れは未検証。
女性寄せ（低域抑制・上位倍音・平滑化LPC包絡ワープ）はストレス入力とブロック分割テストに含めたが、実音声の聴感評価は未実施。
Lint CLIはGradleプロジェクトとして扱われるため、Wrapperなしの直接実行ではプロジェクト検査を完了できず、合格扱いにしていない。Javaコンパイルは `-Xlint:all -Werror` で通過している。

## ピッチ測定

220Hz正弦波、2秒入力、最初の0.5秒を除外。90〜470Hzを0.5Hz刻みで探索した主ピーク。
44.1kHzと48kHzで同じ測定結果。

| 設定 | 理論周波数 | 主ピーク |
|---|---:|---:|
| -12半音 | 110.000Hz | 107.5Hz |
| -5半音 | 164.814Hz | 163.5Hz |
| 0半音 | 220.000Hz | 220.0Hz |
| +5半音 | 293.665Hz | 295.5Hz |
| +12半音 | 440.000Hz | 445.0Hz |

判定条件はこの試験音に対して理論値との差8Hz未満。
短い40ms幅での初回試験は-12半音が120Hzとなり不合格だった。80ms幅に調整し上記結果を得た。
この誤差・遅延とのトレードオフは方式の制約であり、音楽用の精密ピッチや自然な声質変換を保証しない。
実際の声、他の基本周波数、子音、雑音、連続会話の聴感評価は未実施。

## 残る確認

- APKは `app/build/outputs/apk/debug/local-voice-debug.apk` に生成済み。デバッグ署名、v2/v3署名、zipalignを検証済み。
- Android APIの実機型検証・インストール・起動は未実施。
- ネイティブJNI・NDKは使用せず、Java DSPをAPKへ収録した。
- 変声コントロールと録音ファイルをMainActivity内の上下2パネルに統合した。
- AndroidのAPI互換・Lint・通知・AudioRecord/AudioTrack・機器切替・電池消費は未確認。
- 実機の往復遅延・音切れ・イヤホン抜去時の出力安全性は未測定。
- 2時間録音、容量不足、OS強制終了の実機試験は未実施。
- 全チェック項目は `DEVICE_CHECKLIST.md` に記載。

実機受入を通すまでは、実用版／実機動作確認済みAPKと表記しない。
