package jp.localvoice;

/** Runtime-neutral boundary for one stateful LLVC frame. */
interface LlvcKernel {
    int frameSize();
    void process(float[] input,float[] output);
    /** Clears recurrent state before processing another independent utterance. */
    default void reset(){}
    default void close(){}
}
