package jp.localvoice;

import java.util.Arrays;

/** Allocation-free streaming sample-rate conversion used around the 16 kHz model. */
final class StreamingResampler {
    private static final int CAPACITY=32768, TAPS=63;
    private final int inputRate,outputRate;
    private final float[] ring=new float[CAPACITY],history=new float[TAPS];
    private final float[] lowPass;
    private long writeIndex;
    private double readPosition;
    private int historyPosition;

    StreamingResampler(int inputRate,int outputRate){
        if(inputRate<=0||outputRate<=0)throw new IllegalArgumentException("sample rate");
        this.inputRate=inputRate;this.outputRate=outputRate;
        lowPass=outputRate<inputRate?makeLowPass((double)outputRate/inputRate):null;
    }
    private static float[] makeLowPass(double ratio){
        float[] result=new float[TAPS];double cutoff=0.46*ratio,sum=0;int middle=(TAPS-1)/2;
        for(int i=0;i<TAPS;i++){
            int x=i-middle;double sinc=x==0?2*cutoff:Math.sin(2*Math.PI*cutoff*x)/(Math.PI*x);
            double window=0.42-0.5*Math.cos(2*Math.PI*i/(TAPS-1))+0.08*Math.cos(4*Math.PI*i/(TAPS-1));
            result[i]=(float)(sinc*window);sum+=result[i];
        }
        for(int i=0;i<TAPS;i++)result[i]/=sum;
        return result;
    }
    private float filter(float sample){
        if(lowPass==null)return sample;
        history[historyPosition]=sample;float value=0;int p=historyPosition;
        for(int i=0;i<TAPS;i++){value+=lowPass[i]*history[p];if(--p<0)p=TAPS-1;}
        if(++historyPosition==TAPS)historyPosition=0;
        return value;
    }
    void push(short[] input,int count){
        if(count<0||count>input.length)throw new IllegalArgumentException("count");
        for(int i=0;i<count;i++)pushOne(input[i]/32768f);
    }
    void push(float[] input,int count){
        if(count<0||count>input.length)throw new IllegalArgumentException("count");
        for(int i=0;i<count;i++)pushOne(input[i]);
    }
    private void pushOne(float sample){
        if(writeIndex-(long)Math.floor(readPosition)>=CAPACITY-2)throw new IllegalStateException("resampler overflow");
        ring[(int)(writeIndex&(CAPACITY-1))]=filter(sample);writeIndex++;
    }
    int pull(float[] output,int offset,int count){
        if(offset<0||count<0||offset+count>output.length)throw new IllegalArgumentException("output range");
        int made=0;double step=(double)inputRate/outputRate;
        while(made<count&&readPosition+1<writeIndex){
            long base=(long)Math.floor(readPosition);double fraction=readPosition-base;
            float a=ring[(int)(base&(CAPACITY-1))],b=ring[(int)((base+1)&(CAPACITY-1))];
            output[offset+made]=(float)(a+(b-a)*fraction);made++;readPosition+=step;
        }
        return made;
    }
    void reset(){
        Arrays.fill(ring,0);Arrays.fill(history,0);
        writeIndex=0;readPosition=0;historyPosition=0;
    }
}
