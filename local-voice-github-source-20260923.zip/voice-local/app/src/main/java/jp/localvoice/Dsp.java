package jp.localvoice;

import java.util.Arrays;

final class Dsp implements VoiceProcessor {
    private static final int SIZE=8192;
    private static final double PI=Math.PI;
    private final float[] ring=new float[SIZE];
    private final float rate,span;
    private int head;
    private double phase,carrier;
    private float pitch=1,gain=1,tone,robot,female,gate;
    private float targetPitch=1,targetGain=1,targetTone,targetRobot,targetFemale,targetGate;
    private float low,chest,presence,envelope,previousInput,previousHigh;
    private final FormantWarp formantWarp;

    private Dsp(int sampleRate){
        rate=sampleRate;span=sampleRate*0.08f;
        formantWarp=new FormantWarp(sampleRate);
    }
    static Dsp create(int sampleRate){
        return sampleRate==48000 || sampleRate==44100 ? new Dsp(sampleRate) : null;
    }
    @Override public String engineId(){return "legacy-dsp";}
    @Override public void reset(){
        Arrays.fill(ring,0);head=0;phase=0;carrier=0;
        pitch=1;gain=1;tone=0;robot=0;female=0;gate=0;
        targetPitch=1;targetGain=1;targetTone=0;targetRobot=0;targetFemale=0;targetGate=0;
        low=0;chest=0;presence=0;envelope=0;previousInput=0;previousHigh=0;
        formantWarp.reset();
    }
    private static float clamp(float value,float minimum,float maximum){
        return Math.max(minimum,Math.min(maximum,value));
    }
    private float read(double delay){
        double position=head-delay;
        while(position<0)position+=SIZE;
        int a=((int)position)%SIZE;
        float fraction=(float)(position-Math.floor(position));
        return ring[a]*(1-fraction)+ring[(a+1)%SIZE]*fraction;
    }
    private void set(float semitones,float decibels,float color,float metallic,float feminine,boolean noiseGate){
        targetPitch=(float)Math.pow(2,clamp(semitones,-12,12)/12f);
        targetGain=(float)Math.pow(10,clamp(decibels,-18,12)/20f);
        targetTone=clamp(color,-1,1);
        targetRobot=clamp(metallic,0,1);
        targetFemale=clamp(feminine,0,1);
        targetGate=noiseGate?1:0;
    }
    @Override public void process(short[] input,short[] output,int count,float semitones,float decibels,
        float color,float metallic,float feminine,boolean noiseGate){
        if(count<0 || count>input.length || count>output.length)throw new IllegalArgumentException("count");
        set(semitones,decibels,color,metallic,feminine,noiseGate);
        float smoothing=1f-(float)Math.exp(-1f/(rate*0.01f));
        float lowAlpha=1f-(float)Math.exp(-2f*PI*1200f/rate);
        float chestAlpha=1f-(float)Math.exp(-2f*PI*520f/rate);
        float presenceAlpha=1f-(float)Math.exp(-2f*PI*3200f/rate);
        float dcAlpha=(float)Math.exp(-2f*PI*50f/rate);
        for(int i=0;i<count;i++){
            pitch+=smoothing*(targetPitch-pitch);
            gain+=smoothing*(targetGain-gain);
            tone+=smoothing*(targetTone-tone);
            robot+=smoothing*(targetRobot-robot);
            female+=smoothing*(targetFemale-female);
            gate+=smoothing*(targetGate-gate);
            float x=input[i]/32768f;
            float high=dcAlpha*(previousHigh+x-previousInput);
            previousInput=x;previousHigh=high;
            envelope=Math.max(Math.abs(high),envelope*0.9995f);
            float gateGain=clamp(envelope/0.008f,0,1);
            x=high*(1-gate+gate*gateGain*gateGain);
            ring[head]=x;
            double second=phase+0.5;if(second>=1)second-=1;
            float weight=(float)(0.5-0.5*Math.cos(2*PI*phase));
            float shifted=read(8+phase*span)*weight+read(8+second*span)*(1-weight);
            float blend=Math.min(1,Math.abs(pitch-1)*100);
            float y=blend*shifted+(1-blend)*read(8+span*0.5);
            phase+=(1-pitch)/span;phase-=Math.floor(phase);
            low+=lowAlpha*(y-low);
            chest+=chestAlpha*(y-chest);
            presence+=presenceAlpha*(y-presence);
            // Female-voice mode: reduce chest-range energy, lift upper
            // harmonics, and add two vocal-resonance bands. This is a
            // lightweight formant-like stage, not AI or full formant warping.
            float warped=formantWarp.process(y,female);
            y+=female*0.55f*(warped-y);
            y-=female*0.24f*chest;
            y+=female*0.22f*(y-low);
            y+=female*0.10f*(y-presence);
            y+=tone*(y-low);
            y*=(1-robot)+robot*(float)Math.cos(carrier);
            carrier+=2*PI*70/rate;if(carrier>=2*PI)carrier-=2*PI;
            y*=gain;
            float absolute=Math.abs(y);
            if(absolute>0.8f)y=Math.copySign(0.8f+0.2f*(float)Math.tanh((absolute-0.8f)/0.2f),y);
            output[i]=(short)(clamp(y,-0.999f,0.999f)*32767);
            head=(head+1)%SIZE;
        }
    }

}
