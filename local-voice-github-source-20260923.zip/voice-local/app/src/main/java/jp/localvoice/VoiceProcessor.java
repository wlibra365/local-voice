package jp.localvoice;

/** Block voice processor boundary used to replace the legacy DSP safely. */
interface VoiceProcessor {
    String engineId();
    /** Bounded post-conversion tone adjustments; unsupported engines may ignore them. */
    default void setColorControls(float clarity,float warmth){}
    default void setVoiceTexture(float breath){}
    void process(short[] input,short[] output,int count,float semitones,float decibels,
        float color,float metallic,float feminine,boolean noiseGate);
    /** Starts an independent utterance without rebuilding the processor. */
    default void reset(){}
    default void close(){}
}
