package jp.localvoice;

import android.content.Context;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.zip.*;
import org.json.JSONObject;

/** Offline model registry. Every imported voice is a separate, validated LLVC model. */
final class SpeakerModels {
    static final String BUILTIN="builtin";
    static final class Entry {
        final String id,name;
        Entry(String id,String name){this.id=id;this.name=name;}
        @Override public String toString(){return name;}
    }
    private SpeakerModels(){}
    static void verify(Context context,String speakerId)throws Exception{
        LlvcModelPackage pack=LlvcModelPackage.load(context,speakerId);
        try(OnnxCheck check=new OnnxCheck(pack)){check.verify();}
    }
    static List<Entry> list(Context context){
        ArrayList<Entry> entries=new ArrayList<>();entries.add(new Entry(BUILTIN,"標準の女性声"));
        File root=new File(context.getFilesDir(),"voice_models/installed");File[] folders=root.listFiles();
        if(folders==null)return entries;
        Arrays.sort(folders,Comparator.comparing(File::getName));
        for(File folder:folders){
            if(!folder.isDirectory()||!folder.getName().matches("[a-f0-9]{24}"))continue;
            try{
                File manifest=new File(folder,"model-package.json");if(manifest.length()>65536)continue;
                byte[] bytes=new byte[(int)manifest.length()];try(InputStream input=new FileInputStream(manifest)){
                    int n=0;while(n<bytes.length){int got=input.read(bytes,n,bytes.length-n);if(got<0)throw new IOException("manifest truncated");n+=got;}
                }
                String name=new JSONObject(new String(bytes,StandardCharsets.UTF_8)).optString("display_name","").trim();
                if(name.length()>0&&name.length()<=48&&!name.contains("\n"))entries.add(new Entry(folder.getName(),name));
            }catch(Exception ignored){}
        }
        return entries;
    }
    static Entry install(Context context,InputStream archive)throws Exception{
        File root=new File(context.getFilesDir(),"voice_models/installed");
        if(!root.isDirectory()&&!root.mkdirs())throw new IOException("モデル保存先作成失敗");
        if(root.getUsableSpace()<128L*1024*1024)throw new IOException("空き容量128MB以上が必要です");
        File staging=new File(root,"tmp_"+UUID.randomUUID());
        if(!staging.mkdir())throw new IOException("一時保存先作成失敗");
        boolean committed=false;
        try{
            Set<String> seen=new HashSet<>();long total=0;
            try(ZipInputStream zip=new ZipInputStream(new BufferedInputStream(archive))){
                ZipEntry entry;byte[] buffer=new byte[65536];
                while((entry=zip.getNextEntry())!=null){
                    String name=entry.getName();long limit;
                    if("llvc.onnx".equals(name))limit=48L*1024*1024;
                    else if("model-package.json".equals(name)||"LICENSE.model.txt".equals(name))limit=65536;
                    else throw new IOException("ZIP内のファイルは3点だけにしてください");
                    if(entry.isDirectory()||!seen.add(name))throw new IOException("モデルZIPの重複・ディレクトリ不正");
                    try(OutputStream out=new BufferedOutputStream(new FileOutputStream(new File(staging,name)))){
                        long size=0;int n;
                        while((n=zip.read(buffer))!=-1){size+=n;total+=n;
                            if(size>limit||total>50L*1024*1024)throw new IOException("モデルZIPが大きすぎます");
                            out.write(buffer,0,n);
                        }
                    }
                    zip.closeEntry();
                }
            }
            if(seen.size()!=3)throw new IOException("モデルZIPに必要な3ファイルがありません");
            LlvcModelPackage pack=LlvcModelPackage.loadDirectory(staging);
            // Execute a short inference before exposing a user-supplied model.
            try(OnnxCheck check=new OnnxCheck(pack)){check.verify();}
            String hash=LlvcModelPackage.sha256(pack.modelFile),id=hash.substring(0,24);
            if(hash.equals(LlvcModelPackage.sha256(LlvcModelPackage.load(context,BUILTIN).modelFile)))
                throw new IOException("標準モデルと同じ音声です");
            File target=new File(root,id);
            if(target.exists()){
                LlvcModelPackage existing=LlvcModelPackage.loadDirectory(target);
                if(!hash.equals(LlvcModelPackage.sha256(existing.modelFile)))throw new IOException("話者IDが衝突しました");
                return new Entry(id,existing.displayName);
            }
            if(!staging.renameTo(target))throw new IOException("モデル保存失敗");
            committed=true;return new Entry(id,pack.displayName);
        }finally{if(!committed){File[] remains=staging.listFiles();if(remains!=null)for(File file:remains)file.delete();staging.delete();}}
    }
    private static final class OnnxCheck implements AutoCloseable {
        private final OnnxLlvcKernel kernel;
        OnnxCheck(LlvcModelPackage pack)throws Exception{
            if(!OnnxLlvcKernel.runtimePresent())throw new IOException("ONNXランタイム未同梱");
            kernel=new OnnxLlvcKernel(pack);
        }
        void verify(){float[] input=new float[LlvcStreamBridge.MODEL_INPUT_FRAME],output=new float[LlvcStreamBridge.MODEL_FRAME];kernel.reset();kernel.process(input,output);for(float sample:output)if(!Float.isFinite(sample))throw new IllegalStateException("モデル出力が無効");}
        @Override public void close(){kernel.close();}
    }
}
