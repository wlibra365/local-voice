package jp.localvoice;

import java.lang.reflect.*;
import java.nio.*;
import java.util.*;

/** ONNX Runtime adapter kept reflection-based so the offline AAR remains an optional build input. */
final class OnnxLlvcKernel implements LlvcKernel {
    private static final class StateBinding {
        final LlvcModelPackage.State spec;final FloatBuffer buffer;final Object tensor;final int elements;final float[] next;
        StateBinding(LlvcModelPackage.State spec,FloatBuffer buffer,Object tensor,int elements){this.spec=spec;this.buffer=buffer;this.tensor=tensor;this.elements=elements;next=new float[elements];}
    }
    private final Object session,audioTensor;private final FloatBuffer audioBuffer;private final String audioOutput;
    private final StateBinding[] states;private final Map<String,Object> inputs=new HashMap<>();
    private final Method run,getByName,getValue,closeResult,closeSession,closeTensor;

    static boolean runtimePresent(){try{Class.forName("ai.onnxruntime.OrtEnvironment");Class.forName("ai.onnxruntime.OnnxTensor");return true;}catch(ClassNotFoundException error){return false;}}
    OnnxLlvcKernel(LlvcModelPackage pack)throws Exception{
        Class<?> environmentClass=Class.forName("ai.onnxruntime.OrtEnvironment"),tensorClass=Class.forName("ai.onnxruntime.OnnxTensor");
        Class<?> optionsClass=Class.forName("ai.onnxruntime.OrtSession$SessionOptions");Object environment=environmentClass.getMethod("getEnvironment").invoke(null);Object options=optionsClass.getConstructor().newInstance();
        session=environmentClass.getMethod("createSession",String.class,optionsClass).invoke(environment,pack.modelFile.getAbsolutePath(),options);
        Method createTensor=tensorClass.getMethod("createTensor",environmentClass,FloatBuffer.class,long[].class);closeTensor=tensorClass.getMethod("close");
        audioBuffer=direct(LlvcStreamBridge.MODEL_INPUT_FRAME);audioTensor=createTensor.invoke(null,environment,audioBuffer,new long[]{1,1,LlvcStreamBridge.MODEL_INPUT_FRAME});inputs.put(pack.audioInputName,audioTensor);
        states=new StateBinding[pack.states.length];
        for(int i=0;i<states.length;i++){
            LlvcModelPackage.State spec=pack.states[i];int elements=elements(spec.shape);FloatBuffer buffer=direct(elements);Object tensor=createTensor.invoke(null,environment,buffer,spec.shape);
            states[i]=new StateBinding(spec,buffer,tensor,elements);inputs.put(spec.inputName,tensor);
        }
        audioOutput=pack.audioOutputName;run=session.getClass().getMethod("run",Map.class);Class<?> resultClass=Class.forName("ai.onnxruntime.OrtSession$Result");
        getByName=resultClass.getMethod("get",String.class);closeResult=resultClass.getMethod("close");Class<?> valueClass=Class.forName("ai.onnxruntime.OnnxValue");getValue=valueClass.getMethod("getValue");closeSession=session.getClass().getMethod("close");
    }
    @Override public int frameSize(){return LlvcStreamBridge.MODEL_INPUT_FRAME;}
    @Override public synchronized void reset(){
        audioBuffer.clear();while(audioBuffer.hasRemaining())audioBuffer.put(0);audioBuffer.rewind();
        for(StateBinding state:states){
            Arrays.fill(state.next,0);state.buffer.clear();state.buffer.put(state.next);state.buffer.rewind();
        }
    }
    @Override public synchronized void process(float[] input,float[] output){
        if(input.length!=frameSize()||output.length!=LlvcStreamBridge.MODEL_FRAME)throw new IllegalArgumentException("LLVC frame");Object result=null;
        try{
            audioBuffer.clear();audioBuffer.put(input);audioBuffer.rewind();result=run.invoke(session,inputs);
            copyOutput(result,audioOutput,output,output.length);
            for(StateBinding state:states){copyOutput(result,state.spec.outputName,state.next,state.next.length);state.buffer.clear();state.buffer.put(state.next);state.buffer.rewind();}
        }catch(ReflectiveOperationException error){throw new IllegalStateException("LLVC推論失敗",cause(error));}
        finally{if(result!=null)try{closeResult.invoke(result);}catch(ReflectiveOperationException ignored){}}
    }
    private void copyOutput(Object result,String name,float[] target,int expected)throws ReflectiveOperationException{
        Object optional=getByName.invoke(result,name);Object value=((Optional<?>)optional).orElseThrow(()->new IllegalStateException("LLVC出力なし: "+name));Object data=getValue.invoke(value);
        int copied=flatten(data,target,0);if(copied!=expected)throw new IllegalStateException("LLVC出力形状不一致: "+name);
    }
    private static int flatten(Object value,float[] target,int offset){
        if(value instanceof float[]){float[] source=(float[])value;if(offset+source.length>target.length)throw new IllegalStateException("LLVC出力過大");System.arraycopy(source,0,target,offset,source.length);return offset+source.length;}
        if(value==null||!value.getClass().isArray())throw new IllegalStateException("LLVC出力型不一致");int length=Array.getLength(value),position=offset;for(int i=0;i<length;i++)position=flatten(Array.get(value,i),target,position);return position;
    }
    private static FloatBuffer direct(int elements){return ByteBuffer.allocateDirect(elements*4).order(ByteOrder.nativeOrder()).asFloatBuffer();}
    private static int elements(long[] shape){long total=1;for(long dimension:shape)total*=dimension;if(total>Integer.MAX_VALUE)throw new IllegalArgumentException("state size");return (int)total;}
    private static Throwable cause(ReflectiveOperationException error){return error.getCause()==null?error:error.getCause();}
    @Override public void close(){
        for(StateBinding state:states)try{closeTensor.invoke(state.tensor);}catch(ReflectiveOperationException ignored){}
        try{closeTensor.invoke(audioTensor);}catch(ReflectiveOperationException ignored){}try{closeSession.invoke(session);}catch(ReflectiveOperationException ignored){}
    }
}
