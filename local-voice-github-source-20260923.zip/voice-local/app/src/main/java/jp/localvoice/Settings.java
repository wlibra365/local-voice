package jp.localvoice;
final class Settings {
    final float pitch, gain, tone, robot, female, clarity, warmth, breath;
    final boolean gate, monitor, original;
    Settings(float p, float g, float t, float r, float f, boolean n, boolean m, boolean o) {
        this(p,g,t,r,f,n,m,o,0,0,0);
    }
    Settings(float p,float g,float t,float r,float f,boolean n,boolean m,boolean o,float c,float w){
        this(p,g,t,r,f,n,m,o,c,w,0);
    }
    Settings(float p,float g,float t,float r,float f,boolean n,boolean m,boolean o,float c,float w,float b){
        pitch=p;gain=g;tone=t;robot=r;female=f;gate=n;monitor=m;original=o;clarity=c;warmth=w;breath=b;
    }
}
