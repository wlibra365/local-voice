package jp.localvoice;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.*;
import android.os.*;
import android.view.View;
import android.widget.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

/** Dedicated capture, transform and return-playback screen. */
public final class TuningActivity extends Activity {
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final AtomicInteger renderGeneration=new AtomicInteger();
    private final ExecutorService renderExecutor=Executors.newSingleThreadExecutor(task->new Thread(task,"TuningRender"));
    private SharedPreferences prefs;
    private TextView state,pitchLabel,toneLabel,clarityLabel,warmthLabel,breathLabel;
    private SeekBar pitch,tone,clarity,warmth,breath;
    private Spinner speaker;
    private List<SpeakerModels.Entry> speakers;
    private String entrySpeaker,selectedSpeaker,tuningProcessorSpeaker;
    private Button capture,play,baseline,apply;
    private volatile boolean capturing;
    private volatile AudioRecord recorder;
    private AudioTrack player;
    private short[] dry,latestWet,entryWet;
    private int sampleRate=48000,entryPitch,entryTone,entryClarity,entryWarmth,entryBreath;
    private boolean changed,autoPlay=true;
    private VoiceProcessor tuningProcessor;
    private int tuningProcessorRate;
    private volatile boolean destroyed;

    @Override public void onCreate(Bundle saved){
        super.onCreate(saved);prefs=getSharedPreferences("voice",MODE_PRIVATE);
        entryPitch=prefs.getInt("pitch",17);entryTone=prefs.getInt("tone",135);
        entryClarity=prefs.getInt("clarity",100);entryWarmth=prefs.getInt("warmth",100);
        entryBreath=prefs.getInt("breath",0);
        entrySpeaker=prefs.getString("speaker_id",SpeakerModels.BUILTIN);selectedSpeaker=entrySpeaker;
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18),dp(22),dp(18),dp(18));root.setBackgroundColor(Color.rgb(245,247,252));
        ScrollView screen=new ScrollView(this);screen.setFillViewport(true);screen.addView(root);setContentView(screen);
        label(root,"調声",26);state=label(root,"「声を入れる」で短く発声",16);
        label(root,"モデル話者",15);speaker=new Spinner(this);speakers=SpeakerModels.list(this);
        ArrayAdapter<SpeakerModels.Entry> speakerAdapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,speakers);
        speakerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);speaker.setAdapter(speakerAdapter);root.addView(speaker);
        for(int i=0;i<speakers.size();i++)if(speakers.get(i).id.equals(entrySpeaker)){speaker.setSelection(i);break;}
        pitchLabel=label(root,"高さ（LLVC固定）: "+signed(entryPitch-12),15);
        pitch=new SeekBar(this);pitch.setMax(24);pitch.setProgress(entryPitch);root.addView(pitch);
        toneLabel=label(root,"声質: "+toneName(entryTone),15);
        tone=new SeekBar(this);tone.setMax(200);tone.setProgress(entryTone);root.addView(tone);
        clarityLabel=label(root,"輪郭: "+signed(entryClarity-100),15);
        clarity=new SeekBar(this);clarity.setMax(200);clarity.setProgress(entryClarity);root.addView(clarity);
        warmthLabel=label(root,"温かさ: "+signed(entryWarmth-100),15);
        warmth=new SeekBar(this);warmth.setMax(200);warmth.setProgress(entryWarmth);root.addView(warmth);
        breathLabel=label(root,"息感: "+entryBreath,15);
        breath=new SeekBar(this);breath.setMax(100);breath.setProgress(entryBreath);root.addView(breath);
        capture=button(root,"声を入れる",v->toggleCapture());
        LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);root.addView(row);
        play=button(row,"再生",v->playLatest());baseline=button(row,"入場時と比較",v->playBaseline());
        apply=button(root,"適用して戻る",v->applyAndFinish());button(root,"戻る",v->leave());
        setSampleControls(false);
        SeekBar.OnSeekBarChangeListener listener=new SeekBar.OnSeekBarChangeListener(){
            public void onProgressChanged(SeekBar b,int value,boolean user){
                pitchLabel.setText("高さ（LLVC固定）: "+signed(pitch.getProgress()-12));
                toneLabel.setText("声質: "+toneName(tone.getProgress()));
                clarityLabel.setText("輪郭: "+signed(clarity.getProgress()-100));
                warmthLabel.setText("温かさ: "+signed(warmth.getProgress()-100));
                breathLabel.setText("息感: "+breath.getProgress());
                if(user)updateChanged();
            }
            public void onStartTrackingTouch(SeekBar b){autoPlay=true;stopPlayback();}
            public void onStopTrackingTouch(SeekBar b){if(dry!=null)render(false,true);}
        };
        pitch.setOnSeekBarChangeListener(listener);tone.setOnSeekBarChangeListener(listener);
        clarity.setOnSeekBarChangeListener(listener);warmth.setOnSeekBarChangeListener(listener);breath.setOnSeekBarChangeListener(listener);
        speaker.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){
            @Override public void onItemSelected(android.widget.AdapterView<?> parent,View view,int position,long id){
                String next=speakers.get(position).id;if(next.equals(selectedSpeaker))return;
                selectedSpeaker=next;updateChanged();
                if(dry!=null){autoPlay=true;stopPlayback();render(false,true);}
            }
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent){}
        });
    }
    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+0.5f);}
    private void updateChanged(){changed=!selectedSpeaker.equals(entrySpeaker)||pitch.getProgress()!=entryPitch||tone.getProgress()!=entryTone||clarity.getProgress()!=entryClarity||warmth.getProgress()!=entryWarmth||breath.getProgress()!=entryBreath;}
    private TextView label(LinearLayout box,String text,int size){TextView t=new TextView(this);t.setText(text);t.setTextSize(size);t.setPadding(0,dp(7),0,dp(5));box.addView(t);return t;}
    private Button button(LinearLayout box,String text,View.OnClickListener click){Button b=new Button(this);b.setText(text);if(box.getOrientation()==LinearLayout.HORIZONTAL)box.addView(b,new LinearLayout.LayoutParams(0,LinearLayout.LayoutParams.WRAP_CONTENT,1));else box.addView(b);b.setOnClickListener(click);return b;}
    private static String signed(int value){return String.format(Locale.ROOT,"%+d",value);}
    private static String toneName(int value){if(value<70)return "柔らかい "+(value-100);if(value>130)return "澄んだ +"+(value-100);return "自然 "+signed(value-100);}
    private void setSampleControls(boolean enabled){play.setEnabled(enabled&&latestWet!=null);baseline.setEnabled(enabled&&entryWet!=null);apply.setEnabled(enabled&&latestWet!=null);speaker.setEnabled(!capturing);pitch.setEnabled(false);pitch.setVisibility(View.GONE);pitchLabel.setVisibility(View.GONE);tone.setEnabled(!capturing);clarity.setEnabled(!capturing);warmth.setEnabled(!capturing);breath.setEnabled(!capturing);}
    private void toggleCapture(){if(capturing){capturing=false;return;}if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},30);return;}beginCapture();}
    @Override public void onRequestPermissionsResult(int code,String[] p,int[] r){super.onRequestPermissionsResult(code,p,r);if(code==30&&r.length>0&&r[0]==PackageManager.PERMISSION_GRANTED)beginCapture();else if(code==30)state.setText("マイク許可が必要です");}
    private AudioRecord openRecorder(int rate){
        int minimum=AudioRecord.getMinBufferSize(rate,AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_16BIT);
        if(minimum<=0)throw new IllegalStateException("入力形式未対応");
        AudioRecord result=new AudioRecord.Builder().setAudioSource(MediaRecorder.AudioSource.VOICE_RECOGNITION)
            .setAudioFormat(new AudioFormat.Builder().setSampleRate(rate).setChannelMask(AudioFormat.CHANNEL_IN_MONO).setEncoding(AudioFormat.ENCODING_PCM_16BIT).build())
            .setBufferSizeInBytes(Math.max(minimum,3840)).build();
        if(result.getState()!=AudioRecord.STATE_INITIALIZED){result.release();throw new IllegalStateException("マイク初期化失敗");}
        return result;
    }
    private void beginCapture(){
        if(VoiceService.busy){state.setText("通常録音を停止してから調声");return;}
        stopPlayback();renderGeneration.incrementAndGet();capturing=true;capture.setText("収録停止");setSampleControls(false);state.setText("声を待っています…");
        new Thread(this::captureLoop,"TuningCapture").start();
    }
    private void captureLoop(){
        AudioRecord local=null;
        try{
            try{local=openRecorder(48000);sampleRate=48000;}catch(RuntimeException ex){sampleRate=44100;local=openRecorder(sampleRate);}
            recorder=local;short[] block=new short[480];short[] all=new short[sampleRate*13];int total=0,start=-1,quiet=0,voiceAt=-1;
            local.startRecording();
            while(capturing&&total<all.length){
                int n=local.read(block,0,block.length,AudioRecord.READ_BLOCKING);if(n<=0)throw new IllegalStateException("マイク読込エラー");
                int copy=Math.min(n,all.length-total);System.arraycopy(block,0,all,total,copy);float peak=0;
                for(int i=0;i<copy;i++)peak=Math.max(peak,Math.abs((int)block[i])/32768f);
                total+=copy;
                if(peak>=0.018f){if(start<0){start=Math.max(0,total-copy-sampleRate/5);voiceAt=total-copy;handler.post(()->state.setText("発声を収録中…"));}quiet=0;}
                else if(start>=0)quiet+=copy;
                if(start<0&&total>=sampleRate*5)break;
                if(start>=0&&(quiet>=sampleRate*8/10||total-voiceAt>=sampleRate*8))break;
            }
            capturing=false;
            if(start<0){handler.post(()->finishCapture(null,"声が入りませんでした"));return;}
            int end=Math.min(total,start+sampleRate*8);short[] sample=Arrays.copyOfRange(all,start,end);
            handler.post(()->finishCapture(sample,null));
        }catch(RuntimeException ex){String message=ex.getMessage();handler.post(()->finishCapture(null,"収録失敗: "+message));}
        finally{capturing=false;recorder=null;if(local!=null){try{local.stop();}catch(IllegalStateException ignored){}local.release();}}
    }
    private void finishCapture(short[] sample,String error){
        capture.setText(sample==null&&dry==null?"声を入れる":"録り直す");setSampleControls(sample!=null||dry!=null);
        if(sample==null){state.setText(error);setSampleControls(dry!=null);return;}
        dry=sample;entryWet=null;latestWet=null;autoPlay=true;state.setText("変換中…");render(true,true);
    }
    private void render(boolean alsoEntry,boolean playWhenReady){
        if(dry==null)return;int token=renderGeneration.incrementAndGet();short[] source=dry.clone();int rate=sampleRate;
        int p=pitch.getProgress()-12;float t=(tone.getProgress()-100)/100f,c=(clarity.getProgress()-100)/100f,w=(warmth.getProgress()-100)/100f,b=breath.getProgress()/100f;String targetSpeaker=selectedSpeaker;
        latestWet=null;state.setText("変換中…");setSampleControls(false);
        try{renderExecutor.execute(()->{
            try{
                if(token!=renderGeneration.get())return;
                if(alsoEntry){short[] base=convert(source,rate,entryPitch-12,(entryTone-100)/100f,(entryClarity-100)/100f,(entryWarmth-100)/100f,entryBreath/100f,entrySpeaker);if(token!=renderGeneration.get())return;entryWet=base;}
                short[] wet=convert(source,rate,p,t,c,w,b,targetSpeaker);if(token!=renderGeneration.get())return;latestWet=wet;
                handler.post(()->{if(token!=renderGeneration.get()||destroyed)return;state.setText("調整できます");setSampleControls(true);if(playWhenReady&&autoPlay)startPlayback(wet);});
            }catch(RuntimeException error){
                String message=error.getMessage();handler.post(()->{if(token!=renderGeneration.get()||destroyed)return;state.setText("変換失敗"+(message==null?"":": "+message));setSampleControls(dry!=null);});
            }
        });}catch(RejectedExecutionException ignored){}
    }
    private short[] convert(short[] source,int rate,float p,float t,float c,float w,float b,String speakerId){
        VoiceProcessor processor=processor(rate,speakerId);processor.reset();processor.setColorControls(c,w);processor.setVoiceTexture(b);int tail=rate/5;short[] result=new short[source.length+tail];short[] in=new short[480],out=new short[480];
        for(int offset=0;offset<result.length;offset+=480){int n=Math.min(480,result.length-offset);Arrays.fill(in,(short)0);if(offset<source.length)System.arraycopy(source,offset,in,0,Math.min(n,source.length-offset));processor.process(in,out,n,p,0,t,0,1,false);System.arraycopy(out,0,result,offset,n);}
        return result;
    }
    private VoiceProcessor processor(int rate,String speakerId){
        if(tuningProcessor==null||tuningProcessorRate!=rate||!speakerId.equals(tuningProcessorSpeaker)){closeProcessor();tuningProcessor=VoiceProcessorFactory.create(this,rate,speakerId);tuningProcessorRate=rate;tuningProcessorSpeaker=speakerId;}
        return tuningProcessor;
    }
    private void closeProcessor(){
        if(tuningProcessor!=null){tuningProcessor.close();tuningProcessor=null;tuningProcessorRate=0;tuningProcessorSpeaker=null;}
    }
    private void playLatest(){autoPlay=false;if(latestWet==null)render(false,true);else startPlayback(latestWet);}
    private void playBaseline(){autoPlay=false;if(entryWet==null)render(true,false);else startPlayback(entryWet);}
    private void startPlayback(short[] audio){
        stopPlayback();try{player=new AudioTrack.Builder().setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(new AudioFormat.Builder().setSampleRate(sampleRate).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).setEncoding(AudioFormat.ENCODING_PCM_16BIT).build())
            .setBufferSizeInBytes(audio.length*2).setTransferMode(AudioTrack.MODE_STATIC).build();player.write(audio,0,audio.length);player.play();state.setText("再生中");
            AudioTrack expected=player;handler.postDelayed(()->{if(player==expected){stopPlayback();state.setText("調整できます");}},audio.length*1000L/sampleRate+150);
        }catch(RuntimeException ex){stopPlayback();state.setText("再生失敗");}
    }
    private void stopPlayback(){if(player!=null){try{player.stop();}catch(IllegalStateException ignored){}player.release();player=null;}}
    private void applyAndFinish(){
        if(latestWet==null){state.setText("変換が成功してから適用してください");return;}
        int p=pitch.getProgress(),t=tone.getProgress(),c=clarity.getProgress(),w=warmth.getProgress(),b=breath.getProgress();prefs.edit().putInt("pitch",p).putInt("tone",t).putInt("clarity",c).putInt("warmth",w).putInt("breath",b).putString("speaker_id",selectedSpeaker).apply();Settings s=VoiceService.settings;
        VoiceService.settings=new Settings(p-12,s.gain,(t-100)/100f,0,1,s.gate,false,s.original,(c-100)/100f,(w-100)/100f,b/100f);changed=false;finish();
    }
    private void leave(){if(!changed){finish();return;}new AlertDialog.Builder(this).setTitle("調整をどうしますか？").setPositiveButton("適用",(d,w)->applyAndFinish()).setNegativeButton("破棄",(d,w)->{changed=false;finish();}).setNeutralButton("続ける",null).show();}
    @SuppressWarnings("deprecation") @Override public void onBackPressed(){leave();}
    @Override protected void onResume(){super.onResume();if(dry!=null&&!capturing)render(false,false);}
    @Override protected void onPause(){capturing=false;AudioRecord r=recorder;if(r!=null)try{r.stop();}catch(IllegalStateException ignored){}stopPlayback();renderGeneration.incrementAndGet();super.onPause();}
    @Override protected void onDestroy(){
        destroyed=true;renderGeneration.incrementAndGet();
        try{renderExecutor.execute(this::closeProcessor);}catch(RejectedExecutionException ignored){}
        renderExecutor.shutdown();dry=null;latestWet=null;entryWet=null;super.onDestroy();
    }
}
