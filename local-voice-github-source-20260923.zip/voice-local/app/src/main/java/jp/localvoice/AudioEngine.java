package jp.localvoice;

import android.content.Context;
import android.media.*;
import android.os.Process;
import android.os.SystemClock;
import java.io.*;
import java.util.UUID;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.atomic.AtomicReference;

final class AudioEngine implements Runnable {
    private static final int BLOCK=480, POOL=128;
    volatile boolean active=true;
    volatile String status="準備中";
    volatile float peak;
    volatile long frames;
    volatile int rate=48000, underruns;
    private final Context context;
    private final File directory;
    private final boolean original;
    private final Runnable finished;
    private volatile AudioRecord recorder;
    private final AtomicReference<String> failure=new AtomicReference<>();
    private final ArrayBlockingQueue<Packet> free=new ArrayBlockingQueue<>(POOL);
    private final ArrayBlockingQueue<Packet> ready=new ArrayBlockingQueue<>(POOL);
    private volatile boolean producerDone;
    private static final class Packet {
        final short[] wet=new short[BLOCK], dry=new short[BLOCK]; int count;
    }
    AudioEngine(Context context,File directory,boolean original,Runnable finished) {
        this.context=context; this.directory=directory; this.original=original; this.finished=finished;
        for(int i=0;i<POOL;i++)free.add(new Packet());
    }
    void stop() {
        active=false;
        AudioRecord r=recorder;
        if(r!=null)try { r.stop(); } catch(IllegalStateException ignored) {}
    }
    private void fail(String message) { failure.compareAndSet(null,message); stop(); }
    private static boolean external(AudioDeviceInfo d) {
        if(d==null)return false;
        int t=d.getType();
        return t==AudioDeviceInfo.TYPE_WIRED_HEADPHONES || t==AudioDeviceInfo.TYPE_WIRED_HEADSET
            || t==AudioDeviceInfo.TYPE_USB_HEADSET || t==AudioDeviceInfo.TYPE_USB_DEVICE;
    }
    private AudioRecord openRecorder(int sr) {
        int minimum=AudioRecord.getMinBufferSize(sr,AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_16BIT);
        if(minimum<=0)throw new IllegalStateException("入力形式未対応");
        AudioRecord r=new AudioRecord.Builder()
            .setAudioSource(MediaRecorder.AudioSource.VOICE_RECOGNITION)
            .setAudioFormat(new AudioFormat.Builder().setSampleRate(sr).setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT).build())
            .setBufferSizeInBytes(Math.max(minimum,BLOCK*8)).build();
        if(r.getState()!=AudioRecord.STATE_INITIALIZED){r.release();throw new IllegalStateException("マイク初期化失敗");}
        return r;
    }
    private void writer(WavFile wet,WavFile dry) {
        try {
            while(!producerDone || !ready.isEmpty()) {
                Packet p=ready.poll(100,java.util.concurrent.TimeUnit.MILLISECONDS);
                if(p==null)continue;
                try { wet.write(p.wet,p.count); if(dry!=null)dry.write(p.dry,p.count); }
                finally { free.offer(p); }
            }
        } catch(Exception ex) { fail("保存エラー: "+ex.getMessage()); }
        finally {
            try { wet.close(); } catch(IOException ex){failure.compareAndSet(null,"変声音声の確定失敗: "+ex.getMessage());}
            if(dry!=null)try{dry.close();}catch(IOException ex){failure.compareAndSet(null,"元音声の確定失敗: "+ex.getMessage());}
        }
    }
    @SuppressWarnings("deprecation")
    @Override public void run() {
        Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO);
        AudioTrack track=null;
        Thread disk=null;
        WavFile wet=null,dry=null;
        VoiceProcessor dsp=null;
        try {
            if(!active)return;
            if(!directory.isDirectory() && !directory.mkdirs())throw new IOException("保存先を作れません");
            WavFile.recover(directory);
            if(directory.getUsableSpace()<64L*1024*1024)throw new IOException("空き容量64MB以上が必要です");
            try{recorder=openRecorder(48000);}catch(RuntimeException ex){rate=44100;recorder=openRecorder(rate);}
            int minimum=AudioTrack.getMinBufferSize(rate,AudioFormat.CHANNEL_OUT_MONO,AudioFormat.ENCODING_PCM_16BIT);
            if(minimum<=0)throw new IOException("出力形式未対応");
            track=new AudioTrack.Builder()
                .setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                .setAudioFormat(new AudioFormat.Builder().setSampleRate(rate).setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT).build())
                .setBufferSizeInBytes(Math.max(minimum,BLOCK*4)).setTransferMode(AudioTrack.MODE_STREAM)
                .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY).build();
            if(track.getState()!=AudioTrack.STATE_INITIALIZED)throw new IOException("出力初期化失敗");
            track.setVolume(0);
            AudioManager manager=(AudioManager)context.getSystemService(Context.AUDIO_SERVICE);
            for(AudioDeviceInfo device:manager.getDevices(AudioManager.GET_DEVICES_OUTPUTS)) {
                if(external(device)){track.setPreferredDevice(device);break;}
            }
            // Disable monitoring immediately when any route changes. A later block
            // enables it only after checking the actual routed output.
            final AudioTrack routedTrack=track;
            track.addOnRoutingChangedListener(router->{
                try { routedTrack.setVolume(0); } catch(IllegalStateException ignored) {}
            },new android.os.Handler(android.os.Looper.getMainLooper()));
            String base=new java.text.SimpleDateFormat("yyyyMMdd_HHmmss",java.util.Locale.ROOT).format(new java.util.Date())
                +"_"+UUID.randomUUID().toString().substring(0,8);
            wet=new WavFile(new File(directory,base+"_voice.wav"),rate);
            if(original)dry=new WavFile(new File(directory,base+"_original.wav"),rate);
            final WavFile w=wet,d=dry;
            disk=new Thread(()->writer(w,d),"WavWriter");disk.start();
            dsp=VoiceProcessorFactory.create(context,rate); if(dsp==null)throw new IOException("変声エンジン初期化失敗");
            short[] input=new short[BLOCK],output=new short[BLOCK];
            if(!active)return;
            recorder.startRecording();track.play();
            if(recorder.getRecordingState()!=AudioRecord.RECORDSTATE_RECORDING)throw new IOException("マイクを利用できません");
            long spaceCheck=SystemClock.elapsedRealtime();
            while(active) {
                int n=recorder.read(input,0,BLOCK,AudioRecord.READ_BLOCKING);
                if(n<=0){if(active)throw new IOException("マイク読込エラー "+n);break;}
                Settings s=VoiceService.settings;
                dsp.setColorControls(s.clarity,s.warmth);
                dsp.setVoiceTexture(s.breath);
                dsp.process(input,output,n,s.pitch,s.gain,s.tone,s.robot,s.female,s.gate);
                float level=0;for(int i=0;i<n;i++)level=Math.max(level,Math.abs((int)output[i])/32768f);peak=level;
                Packet p=free.poll();
                if(p==null)throw new IOException("保存が追いつきません。欠落を避けるため停止しました");
                p.count=n; System.arraycopy(output,0,p.wet,0,n);
                if(original)System.arraycopy(input,0,p.dry,0,n);
                if(!ready.offer(p)){free.offer(p);throw new IOException("録音キュー超過");}
                frames+=n;
                boolean audible=s.monitor && external(track.getRoutedDevice());
                track.setVolume(audible?0.5f:0f);
                // No blocking on playback: a slow route must not lose recorded input.
                int sent=track.write(output,0,n,AudioTrack.WRITE_NON_BLOCKING);
                if(sent<0)throw new IOException("音声出力エラー "+sent);
                underruns=track.getUnderrunCount();
                status=audible?"録音中・イヤホン確認ON":"録音中・イヤホン確認OFF";
                if(sent<n && audible)status="録音中・モニター混雑（録音は継続）";
                if(frames>=rate*7200L){status="2時間上限で停止";break;}
                long now=SystemClock.elapsedRealtime();
                if(now-spaceCheck>=5000){spaceCheck=now;if(directory.getUsableSpace()<16L*1024*1024)throw new IOException("容量不足のため停止");}
            }
        } catch(Exception | UnsatisfiedLinkError ex){failure.compareAndSet(null,ex.getMessage()==null?ex.toString():ex.getMessage());}
        finally {
            active=false; status="録音を確定中";
            AudioRecord r=recorder; recorder=null;
            if(r!=null){try{r.stop();}catch(IllegalStateException ignored){}r.release();}
            if(track!=null){try{track.setVolume(0);track.stop();}catch(IllegalStateException ignored){}track.release();}
            producerDone=true;
            if(disk!=null){try{disk.join();}catch(InterruptedException ex){Thread.currentThread().interrupt();failure.compareAndSet(null,"保存待機中断");}}
            else {
                if(wet!=null)try{wet.close();}catch(IOException ignored){}
                if(dry!=null)try{dry.close();}catch(IOException ignored){}
            }
            peak=0;
            if(dsp!=null)dsp.close();
            status=failure.get()==null?"停止・保存完了":"停止: "+failure.get();
            finished.run();
        }
    }
}
