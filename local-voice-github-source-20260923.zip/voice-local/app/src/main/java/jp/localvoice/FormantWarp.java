package jp.localvoice;

import java.util.Arrays;

/** Streaming LPC spectral-envelope warp used by the female voice mode. */
final class FormantWarp {
    private static final int N=512,H=128,ORDER=16,RING=2048;
    private final float rate;
    private final float[] input=new float[N], output=new float[RING], window=new float[N];
    private final float[] real=new float[N], imag=new float[N], lpc=new float[ORDER+1];
    private final float[] ratioState=new float[N/2+1];
    private int inputHead,outputHead,hop;

    FormantWarp(float sampleRate){
        rate=sampleRate;
        for(int i=0;i<N;i++)window[i]=(float)(0.5-0.5*Math.cos(2*Math.PI*i/(N-1)));
        for(int i=0;i<ratioState.length;i++)ratioState[i]=1;
    }

    void reset(){
        Arrays.fill(input,0);Arrays.fill(output,0);Arrays.fill(real,0);Arrays.fill(imag,0);Arrays.fill(lpc,0);
        Arrays.fill(ratioState,1);inputHead=0;outputHead=0;hop=0;
    }

    float process(float sample,float amount){
        float filtered=output[outputHead];
        output[outputHead]=0;
        outputHead=(outputHead+1)%RING;
        input[inputHead]=sample;
        inputHead=(inputHead+1)%N;
        if(++hop==H){hop=0;analyze(amount);}
        float mix=Math.max(0,Math.min(1,amount));
        return sample*(1-mix)+filtered*mix;
    }

    private void analyze(float amount){
        float[] frame=new float[N];
        for(int i=0;i<N;i++)frame[i]=input[(inputHead+i)%N]*window[i];
        lpc(frame);
        for(int k=0;k<N;k++){real[k]=frame[k];imag[k]=0;}
        fft(real,imag,false);
        float warp=1f+0.14f*Math.max(0,Math.min(1,amount));
        int start=(outputHead+N-H)%RING;
        for(int k=0;k<=N/2;k++){
            float w=(float)(2*Math.PI*k/N);
            float current=envelope(w),target=envelope(w/warp);
            float raw=(float)Math.pow(clamp(target/(current+0.0001f),0.75f,1.35f),amount);
            ratioState[k]+=0.18f*(raw-ratioState[k]);
            float ratio=ratioState[k];
            real[k]*=ratio;imag[k]*=ratio;
            if(k>0&&k<N/2){real[N-k]=real[k];imag[N-k]=-imag[k];}
        }
        fft(real,imag,true);
        for(int i=0;i<N;i++)output[(start+i)%RING]+=real[i]*window[i]*0.67f;
    }

    private void lpc(float[] frame){
        float[] r=new float[ORDER+1];
        for(int lag=0;lag<=ORDER;lag++){
            double sum=0;for(int i=lag;i<N;i++)sum+=(double)frame[i]*frame[i-lag];r[lag]=(float)(sum/N);
        }
        for(int i=0;i<=ORDER;i++)lpc[i]=0;
        lpc[0]=1;float error=Math.max(r[0],1e-5f);
        for(int i=1;i<=ORDER;i++){
            float acc=r[i];for(int j=1;j<i;j++)acc+=lpc[j]*r[i-j];
            float reflection=-acc/error;reflection=Math.max(-0.98f,Math.min(0.98f,reflection));
            float[] old=lpc.clone();lpc[i]=reflection;
            for(int j=1;j<i;j++)lpc[j]=old[j]+reflection*old[i-j];
            error*=1-reflection*reflection;if(error<1e-6f)break;
        }
    }

    private float envelope(float w){
        double r=1,im=0;
        for(int i=1;i<=ORDER;i++){r+=lpc[i]*Math.cos(w*i);im-=lpc[i]*Math.sin(w*i);}
        return 1f/(float)Math.max(0.08,Math.sqrt(r*r+im*im));
    }

    private static float clamp(float v,float lo,float hi){return Math.max(lo,Math.min(hi,v));}

    private static void fft(float[] r,float[] im,boolean inverse){
        int n=r.length;
        for(int i=1,j=0;i<n;i++){
            int bit=n>>1;for(; (j&bit)!=0;bit>>=1)j^=bit;j^=bit;
            if(i<j){float t=r[i];r[i]=r[j];r[j]=t;t=im[i];im[i]=im[j];im[j]=t;}
        }
        for(int len=2;len<=n;len<<=1){
            double a=2*Math.PI/len*(inverse?1:-1);float wr=(float)Math.cos(a),wi=(float)Math.sin(a);
            for(int i=0;i<n;i+=len){float ur=1,ui=0;for(int j=0;j<len/2;j++){
                int p=i+j,q=p+len/2;float vr=r[q]*ur-im[q]*ui,vi=r[q]*ui+im[q]*ur;
                r[q]=r[p]-vr;im[q]=im[p]-vi;r[p]+=vr;im[p]+=vi;
                float tr=ur*wr-ui*wi;ui=ur*wi+ui*wr;ur=tr;
            }}
        }
        if(inverse)for(int i=0;i<n;i++){r[i]/=n;im[i]/=n;}
    }
}
