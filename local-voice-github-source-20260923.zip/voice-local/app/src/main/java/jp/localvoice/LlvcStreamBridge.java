package jp.localvoice;

import java.util.Arrays;

/**
 * Frames device-rate PCM into the official LLVC 16 kHz stream.
 * Each call receives 32 context samples plus 208 new samples and emits 208.
 * The official stream starts 16 samples into the input; output is held back
 * two model hops to avoid underruns when device blocks and model hops differ.
 */
final class LlvcStreamBridge implements VoiceProcessor {
    static final int MODEL_RATE=16000, MODEL_FRAME=208;
    static final int MODEL_LOOKAHEAD=32,MODEL_SHIFT=16,MODEL_INPUT_FRAME=MODEL_FRAME+MODEL_LOOKAHEAD;
    private final LlvcKernel kernel;
    private final StreamingResampler down,up;
    private final float[] modelInput,modelOutput,scratch=new float[1024],initialShift=new float[MODEL_SHIFT];
    private final int outputDelay;
    private int modelFill,shiftedSamples,delayRemaining;
    private final float colorAlpha,warmAlpha,presenceLowAlpha,presenceHighAlpha,noiseLowAlpha,noiseHighAlpha,envelopeAlpha;
    private float colorLow,warmLow,presenceLow,presenceHigh,noiseLow,noiseHigh,envelope,clarity,warmth,breath;
    private int noiseState=0x5a31c6e9;
    private boolean firstFrame=true;

    LlvcStreamBridge(int deviceRate,LlvcKernel kernel){
        if(deviceRate!=44100&&deviceRate!=48000)throw new IllegalArgumentException("device rate");
        if(kernel==null||kernel.frameSize()!=MODEL_INPUT_FRAME)throw new IllegalArgumentException("LLVC frame");
        this.kernel=kernel;down=new StreamingResampler(deviceRate,MODEL_RATE);up=new StreamingResampler(MODEL_RATE,deviceRate);
        modelInput=new float[MODEL_INPUT_FRAME];modelOutput=new float[MODEL_FRAME];
        outputDelay=(int)Math.ceil(2.0*MODEL_FRAME*deviceRate/MODEL_RATE);
        delayRemaining=outputDelay;
        colorAlpha=alpha(1500,deviceRate);warmAlpha=alpha(350,deviceRate);
        presenceLowAlpha=alpha(900,deviceRate);presenceHighAlpha=alpha(3300,deviceRate);
        noiseLowAlpha=alpha(1600,deviceRate);noiseHighAlpha=alpha(5600,deviceRate);envelopeAlpha=alpha(45,deviceRate);
    }
    @Override public String engineId(){return "llvc";}
    @Override public void setColorControls(float c,float w){clarity=clamp(c);warmth=clamp(w);}
    @Override public void setVoiceTexture(float b){breath=Math.max(0f,Math.min(1f,b));}
    private static float alpha(int frequency,int rate){return (float)(1-Math.exp(-2*Math.PI*frequency/rate));}
    private static float clamp(float value){return Math.max(-1f,Math.min(1f,value));}
    @Override public void reset(){
        down.reset();up.reset();kernel.reset();modelFill=0;shiftedSamples=0;delayRemaining=outputDelay;firstFrame=true;
        colorLow=warmLow=presenceLow=presenceHigh=noiseLow=noiseHigh=envelope=0;noiseState=0x5a31c6e9;
        Arrays.fill(modelInput,0);Arrays.fill(modelOutput,0);Arrays.fill(scratch,0);
    }
    @Override public void close(){kernel.close();}
    @Override public void process(short[] input,short[] output,int count,float semitones,float decibels,
        float color,float metallic,float feminine,boolean noiseGate){
        if(count<0||count>input.length||count>output.length)throw new IllegalArgumentException("count");
        down.push(input,count);
        if(shiftedSamples<MODEL_SHIFT)
            shiftedSamples+=down.pull(initialShift,shiftedSamples,MODEL_SHIFT-shiftedSamples);
        while(true){
            if(shiftedSamples<MODEL_SHIFT)break;
            if(modelFill==0&&!firstFrame)System.arraycopy(modelInput,MODEL_FRAME,modelInput,0,MODEL_LOOKAHEAD);
            int got=down.pull(modelInput,MODEL_LOOKAHEAD+modelFill,MODEL_FRAME-modelFill);modelFill+=got;
            if(modelFill<MODEL_FRAME)break;
            kernel.process(modelInput,modelOutput);up.push(modelOutput,MODEL_FRAME);modelFill=0;firstFrame=false;
        }
        float gain=(float)Math.pow(10,Math.max(-18,Math.min(12,decibels))/20.0);int produced=Math.min(count,delayRemaining);
        Arrays.fill(output,0,produced,(short)0);delayRemaining-=produced;
        while(produced<count){
            int wanted=Math.min(scratch.length,count-produced);int got=up.pull(scratch,0,wanted);
            for(int i=0;i<got;i++){
                float value=scratch[i];
                colorLow+=colorAlpha*(value-colorLow);
                warmLow+=warmAlpha*(value-warmLow);
                presenceLow+=presenceLowAlpha*(value-presenceLow);
                presenceHigh+=presenceHighAlpha*(value-presenceHigh);
                float colored=value+0.48f*clamp(color)*(value-colorLow)
                    +0.48f*clarity*(presenceHigh-presenceLow)+0.42f*warmth*warmLow;
                // Breath is band-limited and gated by the converted voice envelope;
                // no constant hiss is added during pauses. Deterministic reset makes
                // the tuning comparison repeatable for the same utterance.
                envelope+=envelopeAlpha*(Math.abs(value)-envelope);
                noiseState^=noiseState<<13;noiseState^=noiseState>>>17;noiseState^=noiseState<<5;
                float noise=(noiseState>>>8)/8388608f-1f;
                noiseLow+=noiseLowAlpha*(noise-noiseLow);
                noiseHigh+=noiseHighAlpha*(noise-noiseHigh);
                float gate=Math.max(0f,Math.min(1f,(envelope-0.006f)*80f));
                colored+=breath*0.70f*envelope*gate*(noiseHigh-noiseLow);
                output[produced+i]=pcm(colored*gain);
            }
            produced+=got;if(got<wanted)break;
        }
        while(produced<count)output[produced++]=0;
    }
    private static short pcm(float value){
        int sample=Math.round(value*32768);if(sample>32735)sample=32735;if(sample<-32735)sample=-32735;return (short)sample;
    }
}
