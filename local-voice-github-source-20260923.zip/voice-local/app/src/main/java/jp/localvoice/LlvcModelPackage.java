package jp.localvoice;

import android.content.Context;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;
import org.json.*;

/** Strict description of an app-private, offline LLVC ONNX package. */
final class LlvcModelPackage {
    static final class State {
        final String inputName,outputName;final long[] shape;
        State(String inputName,String outputName,long[] shape){this.inputName=inputName;this.outputName=outputName;this.shape=shape;}
    }
    final File modelFile;
    final String engineId,displayName,audioInputName,audioOutputName;
    final State[] states;
    private LlvcModelPackage(File modelFile,String engineId,String displayName,String audioInputName,String audioOutputName,State[] states){
        this.modelFile=modelFile;this.engineId=engineId;this.displayName=displayName;this.audioInputName=audioInputName;this.audioOutputName=audioOutputName;this.states=states;
    }
    static LlvcModelPackage load(Context context)throws Exception{
        return load(context,"builtin");
    }
    static LlvcModelPackage load(Context context,String speakerId)throws Exception{
        if(!speakerId.matches("builtin|[a-f0-9]{24}"))throw new IOException("話者ID不正");
        File root=new File(context.getFilesDir(),"voice_models/llvc");
        if("builtin".equals(speakerId))installBundled(context,root);
        else root=new File(context.getFilesDir(),"voice_models/installed/"+speakerId);
        return loadDirectory(root);
    }
    static LlvcModelPackage loadDirectory(File root)throws Exception{
        File manifest=new File(root,"model-package.json");if(!manifest.isFile())throw new FileNotFoundException("LLVCモデル未導入");
        JSONObject json=new JSONObject(readText(manifest));
        if(json.getInt("schema_version")!=1||!"onnx".equals(json.getString("model_format")))throw new IOException("LLVC形式不一致");
        if(json.getInt("sample_rate_hz")!=LlvcStreamBridge.MODEL_RATE||json.getInt("frame_samples")!=LlvcStreamBridge.MODEL_FRAME)
            throw new IOException("LLVC音声形式不一致");
        if(json.getInt("input_channels")!=1||!json.getBoolean("streaming")||!json.getBoolean("stateful"))throw new IOException("LLVCストリーム条件不一致");
        JSONObject validation=json.getJSONObject("conversion_validation");
        if(!validation.getBoolean("passed")||validation.getInt("tested_frames")<1||validation.getDouble("max_abs_error")<0||validation.getDouble("max_abs_error")>0.01)
            throw new IOException("LLVC変換一致検証なし");
        File model=inside(root,json.getString("model_file"));File license=inside(root,json.getString("license_file"));
        if(!model.isFile()||!license.isFile()||license.length()<20)throw new IOException("LLVCモデル構成不足");
        String expected=json.getString("model_sha256");if(expected.length()!=64||!expected.equals(expected.toLowerCase(Locale.ROOT)))throw new IOException("LLVCハッシュ形式不正");
        if(!expected.equals(sha256(model)))throw new IOException("LLVCモデル破損");
        JSONObject contract=json.getJSONObject("runtime_contract");String audioInput=contract.getString("audio_input_name"),audioOutput=contract.getString("audio_output_name");
        if(audioInput.isEmpty()||audioOutput.isEmpty())throw new IOException("LLVC入出力名なし");
        JSONArray array=contract.getJSONArray("state_tensors");if(array.length()==0||array.length()>16)throw new IOException("LLVC状態定義不正");
        State[] states=new State[array.length()];long total=0;
        for(int i=0;i<states.length;i++){
            JSONObject item=array.getJSONObject(i);JSONArray dimensions=item.getJSONArray("shape");if(dimensions.length()==0||dimensions.length()>8)throw new IOException("LLVC状態形状不正");
            long[] shape=new long[dimensions.length()];long elements=1;
            for(int d=0;d<shape.length;d++){shape[d]=dimensions.getLong(d);if(shape[d]<=0||elements>16000000/shape[d])throw new IOException("LLVC状態サイズ不正");elements*=shape[d];}
            total+=elements;if(total>16000000)throw new IOException("LLVC状態が大きすぎます");
            states[i]=new State(item.getString("input_name"),item.getString("output_name"),shape);
        }
        String displayName=json.optString("display_name","").trim();
        if(displayName.isEmpty()||displayName.length()>48||displayName.contains("\n"))throw new IOException("話者名不正");
        return new LlvcModelPackage(model,json.getString("engine_id"),displayName,audioInput,audioOutput,states);
    }
    private static void installBundled(Context context,File root)throws IOException{
        File manifest=new File(root,"model-package.json");if(manifest.isFile())return;
        String assetRoot="models/llvc";String[] names=context.getAssets().list(assetRoot);if(names==null||names.length==0)return;
        if(!root.isDirectory()&&!root.mkdirs())throw new IOException("モデル保存先作成失敗");
        Arrays.sort(names,(left,right)->"model-package.json".equals(left)?1:"model-package.json".equals(right)?-1:left.compareTo(right));
        for(String name:names){
            if(name.contains("/")||name.contains("\\")||name.startsWith("."))throw new IOException("モデル資産名不正");
            File target=new File(root,name),temporary=new File(root,name+".part");if(target.exists()&&!target.delete())throw new IOException("旧モデル資産削除失敗");
            try(InputStream in=context.getAssets().open(assetRoot+"/"+name);OutputStream out=new BufferedOutputStream(new FileOutputStream(temporary))){byte[] buffer=new byte[1024*1024];int n;while((n=in.read(buffer))!=-1)out.write(buffer,0,n);}
            if(!temporary.renameTo(target))throw new IOException("モデル資産確定失敗");
        }
    }
    private static File inside(File root,String relative)throws IOException{
        File file=new File(root,relative).getCanonicalFile();String base=root.getCanonicalPath()+File.separator;
        if(!file.getPath().startsWith(base))throw new IOException("モデルパス不正");return file;
    }
    private static String readText(File file)throws IOException{
        ByteArrayOutputStream out=new ByteArrayOutputStream();try(InputStream in=new FileInputStream(file)){byte[] buffer=new byte[8192];int n;while((n=in.read(buffer))!=-1){if(out.size()+n>1024*1024)throw new IOException("マニフェスト過大");out.write(buffer,0,n);}}
        return new String(out.toByteArray(),StandardCharsets.UTF_8);
    }
    static String sha256(File file)throws Exception{
        MessageDigest digest=MessageDigest.getInstance("SHA-256");try(InputStream in=new BufferedInputStream(new FileInputStream(file))){byte[] buffer=new byte[1024*1024];int n;while((n=in.read(buffer))!=-1)digest.update(buffer,0,n);}
        StringBuilder result=new StringBuilder(64);for(byte value:digest.digest())result.append(String.format(Locale.ROOT,"%02x",value&255));return result.toString();
    }
}
