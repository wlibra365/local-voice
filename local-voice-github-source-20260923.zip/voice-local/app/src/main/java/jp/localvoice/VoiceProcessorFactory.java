package jp.localvoice;

import android.content.Context;

/** Central construction point. Candidate engines enter here after quality validation. */
final class VoiceProcessorFactory {
    private static volatile String status="変換: 起動待ち";
    private VoiceProcessorFactory(){}
    static VoiceProcessor createBaseline(int sampleRate){
        return Dsp.create(sampleRate);
    }
    static VoiceProcessor create(Context context,int sampleRate){
        String speakerId=context.getSharedPreferences("voice",Context.MODE_PRIVATE).getString("speaker_id","builtin");
        return create(context,sampleRate,speakerId);
    }
    static VoiceProcessor create(Context context,int sampleRate,String speakerId){
        try{
            LlvcModelPackage pack=LlvcModelPackage.load(context.getApplicationContext(),speakerId);
            if(!OnnxLlvcKernel.runtimePresent())throw new IllegalStateException("ONNXランタイム未同梱");
            VoiceProcessor result=new LlvcStreamBridge(sampleRate,new OnnxLlvcKernel(pack));status="変換: "+pack.displayName;return result;
        }catch(Exception | LinkageError error){
            status="変換: モデル読込失敗";
            throw new IllegalStateException("話者モデルを開けません: "+error.getMessage(),error);
        }
    }
    static String status(){return status;}
    static boolean usingLlvc(){return status.startsWith("変換: ")&&!status.equals("変換: 起動待ち")&&!status.equals("変換: モデル読込失敗");}
}
