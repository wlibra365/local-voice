#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
test_dir=$(mktemp -d)
java com.sun.tools.javac.Main -Xlint:all -Werror -d "$test_dir" \
  app/src/main/java/jp/localvoice/VoiceProcessor.java app/src/main/java/jp/localvoice/Dsp.java app/src/main/java/jp/localvoice/FormantWarp.java app/src/main/java/jp/localvoice/WavFile.java \
  app/src/main/java/jp/localvoice/LlvcKernel.java app/src/main/java/jp/localvoice/StreamingResampler.java app/src/main/java/jp/localvoice/LlvcStreamBridge.java \
  tests/DspTest.java tests/WavTest.java tests/LlvcBridgeTest.java tests/ParseJava.java
java -cp "$test_dir" jp.localvoice.DspTest
java -cp "$test_dir" jp.localvoice.WavTest
java -cp "$test_dir" jp.localvoice.LlvcBridgeTest
java -cp "$test_dir" ParseJava app/src/main/java/jp/localvoice/*.java
python3 tools/prepare_comparison.py --self-test
python3 tools/verify_model_package.py --self-test
python3 tools/export_llvc_onnx.py --self-test
python3 tools/package_speaker_model.py --self-test
python3 tools/check_llvc_teacher_pairs.py --self-test
python3 tools/segment_llvc_pairs.py --self-test
python3 tools/llvc_training.py --self-test
python3 tools/finalize_llvc_voice.py --self-test
