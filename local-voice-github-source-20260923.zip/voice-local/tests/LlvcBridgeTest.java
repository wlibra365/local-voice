package jp.localvoice;

public final class LlvcBridgeTest {
    private static void check(boolean value,String message){if(!value)throw new AssertionError(message);}
    private static final class IdentityKernel implements LlvcKernel {
        int calls,resets;
        @Override public int frameSize(){return LlvcStreamBridge.MODEL_INPUT_FRAME;}
        @Override public void process(float[] input,float[] output){System.arraycopy(input,LlvcStreamBridge.MODEL_LOOKAHEAD,output,0,output.length);calls++;}
        @Override public void reset(){resets++;}
    }
    private static final class ProbeKernel implements LlvcKernel {
        float[] first,second;
        int calls;
        @Override public int frameSize(){return LlvcStreamBridge.MODEL_INPUT_FRAME;}
        @Override public void process(float[] input,float[] output){
            if(calls==0)first=input.clone();
            if(calls==1)second=input.clone();
            java.util.Arrays.fill(output,0.35f);calls++;
        }
    }
    public static void main(String[] args){
        int cases=0;
        for(int deviceRate:new int[]{44100,48000}){
            StreamingResampler down=new StreamingResampler(deviceRate,16000);short[] input=new short[deviceRate];
            for(int i=0;i<input.length;i++)input[i]=(short)(12000*Math.sin(2*Math.PI*1000*i/deviceRate));
            float[] converted=new float[17000];int count=0;
            for(int offset=0;offset<input.length;offset+=480){
                int size=Math.min(480,input.length-offset);short[] part=new short[size];System.arraycopy(input,offset,part,0,size);
                down.push(part,size);count+=down.pull(converted,count,converted.length-count);
            }
            check(Math.abs(count-16000)<=2,"downsample length "+deviceRate+": "+count);
            double energy=0;for(int i=200;i<count;i++)energy+=converted[i]*converted[i];check(energy>100,"downsample signal");cases++;
            IdentityKernel kernel=new IdentityKernel();LlvcStreamBridge bridge=new LlvcStreamBridge(deviceRate,kernel);
            short[] block=new short[480],output=new short[480];long nonzero=0;
            for(int frame=0;frame<200;frame++){
                for(int i=0;i<block.length;i++)block[i]=(short)(9000*Math.sin(2*Math.PI*220*(frame*480L+i)/deviceRate));
                bridge.process(block,output,output.length,0,0,0,0,1,false);
                for(short sample:output)if(sample!=0)nonzero++;
            }
            check(kernel.calls>100,"kernel not framed");check(nonzero>deviceRate/2,"bridge output missing");cases++;
            bridge.reset();short[] first=new short[480*40],second=new short[first.length];
            for(int frame=0;frame<40;frame++){
                for(int i=0;i<block.length;i++)block[i]=(short)(7000*Math.sin(2*Math.PI*190*(frame*480L+i)/deviceRate));
                bridge.process(block,output,output.length,0,0,0,0,1,false);System.arraycopy(output,0,first,frame*480,480);
            }
            bridge.reset();
            for(int frame=0;frame<40;frame++){
                for(int i=0;i<block.length;i++)block[i]=(short)(7000*Math.sin(2*Math.PI*190*(frame*480L+i)/deviceRate));
                bridge.process(block,output,output.length,0,0,0,0,1,false);System.arraycopy(output,0,second,frame*480,480);
            }
            check(java.util.Arrays.equals(first,second),"bridge reset consistency");check(kernel.resets==2,"kernel reset");cases++;
            ProbeKernel probe=new ProbeKernel();LlvcStreamBridge aligned=new LlvcStreamBridge(deviceRate,probe);
            StreamingResampler reference=new StreamingResampler(deviceRate,16000);
            short[] constant=new short[480];java.util.Arrays.fill(constant,(short)12000);
            float[] expected=new float[16+208*2];int expectedCount=0;int dropouts=0;
            for(int frame=0;frame<160;frame++){
                aligned.process(constant,output,480,0,0,0,0,1,false);
                if(expectedCount<expected.length){reference.push(constant,480);
                    expectedCount+=reference.pull(expected,expectedCount,expected.length-expectedCount);}
                if(frame>12)for(short sample:output)if(sample<10000)dropouts++;
            }
            check(probe.calls>2&&expectedCount==expected.length,"probe frames");
            for(int i=0;i<32;i++)check(probe.first[i]==0,"first frame prefix "+i);
            for(int i=0;i<208;i++)check(Math.abs(probe.first[32+i]-expected[16+i])<1e-6,"official initial shift "+i);
            for(int i=0;i<32;i++)check(probe.second[i]==probe.first[208+i],"previous-frame context "+i);
            for(int i=0;i<208;i++)check(Math.abs(probe.second[32+i]-expected[224+i])<1e-6,"next frame "+i);
            check(dropouts==0,"steady-state model output underruns: "+dropouts);cases++;
            LlvcStreamBridge neutral=new LlvcStreamBridge(deviceRate,new IdentityKernel());
            LlvcStreamBridge colored=new LlvcStreamBridge(deviceRate,new IdentityKernel());
            colored.setColorControls(1,-1);
            short[] plain=new short[480],bright=new short[480];long difference=0;
            for(int frame=0;frame<100;frame++){
                for(int i=0;i<480;i++)block[i]=(short)(8000*Math.sin(2*Math.PI*1200*(frame*480L+i)/deviceRate));
                neutral.process(block,plain,480,0,0,0,0,1,false);
                colored.process(block,bright,480,0,0,0,0,1,false);
                if(frame>12)for(int i=0;i<480;i++)difference+=Math.abs((int)plain[i]-bright[i]);
            }
            check(difference>100000,"LLVC tone controls have no effect");cases++;
            LlvcStreamBridge dry=new LlvcStreamBridge(deviceRate,new IdentityKernel());
            LlvcStreamBridge airy=new LlvcStreamBridge(deviceRate,new IdentityKernel());airy.setVoiceTexture(0.7f);
            long textureDifference=0,silenceEnergy=0;
            for(int frame=0;frame<120;frame++){
                for(int i=0;i<480;i++)block[i]=frame<20?(short)0:(short)(9000*Math.sin(2*Math.PI*180*(frame*480L+i)/deviceRate));
                dry.process(block,plain,480,0,0,0,0,1,false);
                airy.process(block,bright,480,0,0,0,0,1,false);
                for(int i=0;i<480;i++){if(frame<15)silenceEnergy+=Math.abs((int)bright[i]);if(frame>30)textureDifference+=Math.abs((int)plain[i]-bright[i]);}
            }
            check(silenceEnergy==0,"breath introduces silence hiss");
            check(textureDifference>10000,"breath control has no audible-range effect");cases++;
        }
        System.out.println("PASS "+cases+" LLVC bridge cases");
    }
}
