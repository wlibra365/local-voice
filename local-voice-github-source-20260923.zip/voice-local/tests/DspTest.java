package jp.localvoice;

import java.util.Random;

public final class DspTest {
    private static final double PI=Math.PI;
    private static void check(boolean value,String message){if(!value)throw new AssertionError(message);}
    private static short[] sine(int rate,int count,double frequency){
        short[] result=new short[count];
        for(int i=0;i<count;i++)result[i]=(short)(8000*Math.sin(2*PI*frequency*i/rate));
        return result;
    }
    private static double power(short[] data,int rate,double frequency){
        double real=0,imaginary=0;int start=rate/2;
        for(int i=start;i<data.length;i++){
            double angle=2*PI*frequency*i/rate;
            real+=data[i]*Math.cos(angle);imaginary+=data[i]*Math.sin(angle);
        }
        return real*real+imaginary*imaginary;
    }
    public static void main(String[] args){
        int cases=0;
        for(int rate:new int[]{44100,48000}){
            short[] input=sine(rate,rate*2,220),output=new short[input.length];
            for(float shift:new float[]{-12,-5,0,5,12}){
                Dsp dsp=Dsp.create(rate);
                for(int offset=0;offset<input.length;offset+=480){
                    int count=Math.min(480,input.length-offset);
                    short[] in=new short[count],out=new short[count];
                    System.arraycopy(input,offset,in,0,count);
                    dsp.process(in,out,count,shift,0,0,0,0,false);
                    System.arraycopy(out,0,output,offset,count);
                }
                double expected=220*Math.pow(2,shift/12),best=0,peak=0;
                for(double frequency=90;frequency<470;frequency+=0.5){
                    double value=power(output,rate,frequency);
                    if(value>best){best=value;peak=frequency;}
                }
                System.out.printf("pitch %d %.0f expected=%.3f peak=%.1f%n",rate,shift,expected,peak);
                check(Math.abs(peak-expected)<8,"pitch "+shift+": "+peak);cases++;
            }
            Dsp silence=Dsp.create(rate);short[] zero=new short[rate],silent=new short[rate];
            silence.process(zero,silent,rate,0,0,0,0,1,true);
            for(short value:silent)check(value==0,"silence");cases++;
            Dsp whole=Dsp.create(rate),chunked=Dsp.create(rate);
            short[] a=new short[input.length],b=new short[input.length];
            whole.process(input,a,input.length,7,3,-0.5f,0.2f,0.8f,true);
            for(int offset=0;offset<input.length;offset+=127){
                int count=Math.min(127,input.length-offset);
                short[] in=new short[count],out=new short[count];System.arraycopy(input,offset,in,0,count);
                chunked.process(in,out,count,7,3,-0.5f,0.2f,0.8f,true);System.arraycopy(out,0,b,offset,count);
            }
            check(java.util.Arrays.equals(a,b),"chunk consistency");cases++;
            Dsp reusable=Dsp.create(rate);short[] first=new short[input.length],second=new short[input.length];
            reusable.process(input,first,input.length,5,0,0.35f,0,1,false);reusable.reset();
            reusable.process(input,second,input.length,5,0,0.35f,0,1,false);
            check(java.util.Arrays.equals(first,second),"reset consistency");cases++;
            Dsp stress=Dsp.create(rate);Random random=new Random(17);short[] noise=new short[480],out=new short[480];
            for(int run=0;run<2000;run++){
                for(int i=0;i<noise.length;i++)noise[i]=(short)random.nextInt();
                stress.process(noise,out,out.length,run%25-12,12,run%3-1,run%2,run%2,run%2==1);
                for(short value:out)check(value>=-32735 && value<=32735,"range");
            }cases++;
        }
        System.out.println("PASS "+cases+" DSP cases");
    }
}
