# 音声モデルの受入手順

現在のAPKにはKoeAI公式LLVC候補を同梱しています。`app/src/main/assets/models/llvc/` に状態付きONNX、マニフェスト、MITライセンス本文を置き、次を実行すると内容を検証できます。

```bash
python3 tools/verify_model_package.py path/to/model-package.json
```

検証する内容は、モデルファイルのSHA-256、形式、ライセンスファイルの存在、サンプルレート、モノラル入力、状態保持、フレーム長、ストリーミング指定、出典URLです。検証通過は再配布許諾や音質の保証ではありません。配布前にはモデルカードと依存物を個別に確認します。

採用候補はKoeAI LLVCです。公式設定の実行時に必要な部分は `llvc-official-config.json` に出典コミットとともに固定しました。モデルは16kHz・208サンプル出力、32サンプル先読みを含む240サンプル入力です。チェックポイント `G_500000.pth` の公開SHA-256は `cceb7ab9621f84d62d283725ae3281cacb04f762d6a088fe3e97c1a29d4b8c0e`、同梱ONNXのSHA-256は `57a9664aa7b13633f38e7c676f32ab3b9753b6bc42a9ab7a68affdb682894b5c` です。

公式LLVCリポジトリ、`G_500000.pth`、公式設定、ライセンスを用意した後は、次のツールで同じ状態バッファ付きONNXを再生成できます。ツール自体は変換中に通信しません。

```bash
python3 tools/export_llvc_onnx.py \
  --llvc-repo /path/to/LLVC \
  --checkpoint /path/to/G_500000.pth \
  --config /path/to/LLVC/experiments/llvc/config.json \
  --license /path/to/LLVC/LICENSE \
  --output app/src/main/assets/models/llvc
python3 tools/verify_model_package.py app/src/main/assets/models/llvc/model-package.json
```

Android用 `onnxruntime-mobile.aar` は `app/libs/` へ置きます。手動ビルドはAARのJavaクラスとABI別ネイティブライブラリ、モデル資産を検出してAPKへ収録します。どれかが欠ける場合、LLVCを名乗らず旧DSP試作へ戻ります。

## 複数のモデル話者

LLVCは入力へ話者番号を渡すモデルではなく、チェックポイントごとに変換先が固定された any-to-one 方式です。現在同梱しているチェックポイントの変換先は `f_8312_ls360` の1種類だけです。別の声を用意するには、権利を確認した音声で同じ16kHz/208サンプルの構造を学習した別チェックポイントが必要です。単に `display_name` を変えても別の声にはなりません。現時点で追加の学習済み互換モデルは同梱していません。年齢名やキャラクター名だけを追加の声として扱いません。

互換チェックポイントを用意できた場合は、`--checkpoint` と `--config` を実物に替えて以下を実行します。PyTorchの `.pth` は信頼できる入手元のものだけを変換用PCで開いてください。AndroidアプリにはONNXだけを取り込みます。

```bash
python3 tools/export_llvc_onnx.py \
  --llvc-repo /path/to/LLVC --checkpoint /path/to/your_checkpoint.pth \
  --config /path/to/config.json --license /path/to/LICENSE \
  --engine-id your-own-voice-id --display-name '大人の女性声' \
  --output /path/to/adult-model
python3 tools/verify_model_package.py /path/to/adult-model/model-package.json
python3 tools/package_speaker_model.py --package /path/to/adult-model --output /path/to/adult-model.zip
```

アプリの「話者モデルを追加」でZIPを選びます。アプリは3ファイル・サイズ・SHA-256・ストリーム契約・試験推論を確認してから端末に保存します。通常録音と調声は同じ話者を選択可能で、調声では元の発声を別の話者で再変換できます。取り込み時にファイル選択先がクラウドであれば、その提供アプリがダウンロードする場合があります。取り込み後の音声変換自体はオフラインです。

## Ⅲを教師にしたLLVC試作（モデルは未作成）

ⅢのRVC重みを名前変更・ONNX変換してもLLVCにはなりません。権利が確認できる音声を元音声とし、Ⅲによる変換音を教師として、KoeAI公式のLLVC学習コードで別チェックポイントを学習します。学習後は上記の互換チェックポイントと同じ輸出・検証・ZIP化の経路を通し、既存APKの「話者モデルを追加」から取り込みます。APKにRVC・ContentVec・RMVPE・インデックスを追加しないため、既存の実行時モデルサイズや遅延は増えません。

公式LLVCが求めるデータ構造は `train`・`dev`・`val` の下に `PREFIX_original.wav` と `PREFIX_converted.wav` を置く構成です。公式READMEには `python -m minimal_rvc._infer_folder` によるRVC教師音声生成例があります。Ⅲについては、元の例の `--model_path`、変換ピッチ `--f0_up_key` などを実際の声と権利条件に合わせて評価する必要があります。実在しないモデルパスを指定したコマンドは掲載しません。16kHzモノラルPCM16で生成したペアの事前点検は以下です。

```bash
python3 tools/check_llvc_teacher_pairs.py /path/to/iii_teacher_dataset
```

欠損ペア、形式、音声長の20ms超の差、ほぼ無音、クリッピングを検出します。合格は教師声の透明感・話者の一致・モデル品質を保証しません。まず短い日本語サンプルで教師Ⅲの声と学習後のLLVCを聴き比べ、維持できなければAPKには追加しません。公式公開チェックポイントに追加学習用の判別器が見当たらないという公開報告があるため、学習方法は実行環境で確認します。学習と教師変換には端末外のGPU環境が必要です。できあがったモデルの推論はアプリ内でオフラインです。

環境構築と実行コマンドは `training/README.md` を参照してください。公式の学習スクリプトが生成器 `G_*.pth` と判別器 `D_*.pth` を新規に作る経路を使用し、公開済み生成器だけでの追加学習には依存しません。
非公開の学習済み重みは `checkpoint_source_url` に `local://trained/iii-llvc` と記録でき、教師RVCの公開元は別項目へ記録します。
