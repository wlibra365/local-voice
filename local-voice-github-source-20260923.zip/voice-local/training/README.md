# Ⅲ → LLVC 学習環境（GPUマシン用）

このフォルダはPC側の学習用です。Android APKには追加されません。KoeAI公式LLVCのコード・設定を使い、ⅢのRVC変換音を教師として別のLLVCモデルを**新規学習**します。公式公開版には判別器の学習済み重みがないため、生成器・判別器とも学習開始はゼロからです。透明な女性声に到達する保証はありません。

## 実行条件

- NVIDIA GPU、Linux上のDocker EngineとGPUコンテナ実行環境。`docker run --rm --gpus all ... nvidia-smi` が通ること。Docker/NVIDIAの導入方法は各公式文書を参照。
- このリポジトリのソース一式。Ⅲの信頼できる入手元からのRVC重み `III_e250.pth`。日本語の元音声を `training-work/input/train/` と `training-work/input/dev/` に分けて置く。教師モデルの利用条件と音声の利用権は事前確認する。
- 公式LLVCの依存ライブラリをコンテナ構築時に取得するため、初回はネット接続が必要。学習済みデータ・重みは `training-work/` に置き、ソースZIPから除外する。

DockerfileはKoeAI LLVCをコミット `a057f5c5debe07c5a3e462841578fc33e928053a` に固定し、PyTorch/CUDAのベース環境へ公式requirementsとONNX書出し依存を追加します。ベース以外の依存は公式requirementsの版に従います。学習用の `fairseq` / `rmvpe` 重みが実行時に必要になった場合は、公式リポジトリの案内に沿い信頼できる出典から取得します。モデル重み・収録音声はこの配布ソースに含まれません。

## コマンド（ソースの `voice-local/` から）

```bash
docker build -f training/Dockerfile -t local-voice-llvc training
mkdir -p training-work/input/train training-work/input/dev
# 許諾を確認したⅢの重みを training-work/III_e250.pth に配置し、
# 元の日本語WAVを input/train と input/dev に配置する。
docker run --rm --gpus all -v "$PWD:/project:ro" -v "$PWD/training-work:/work" \
  local-voice-llvc python /project/tools/llvc_training.py doctor --repo /opt/llvc
docker run --rm --gpus all -v "$PWD:/project:ro" -v "$PWD/training-work:/work" \
  local-voice-llvc python /project/tools/llvc_training.py teacher --repo /opt/llvc \
  --checkpoint /work/III_e250.pth --train-input /work/input/train \
  --dev-input /work/input/dev --output /work/teacher --pitch 0
docker run --rm -v "$PWD:/project:ro" -v "$PWD/training-work:/work" \
  local-voice-llvc python /project/tools/segment_llvc_pairs.py /work/teacher /work/segments
docker run --rm -v "$PWD:/project:ro" -v "$PWD/training-work:/work" \
  local-voice-llvc python /project/tools/llvc_training.py prepare --repo /opt/llvc \
  --dataset /work/segments --run-dir /work/run
docker run --rm --gpus all -v "$PWD:/project:ro" -v "$PWD/training-work:/work" \
  local-voice-llvc python /project/tools/llvc_training.py train --repo /opt/llvc --run-dir /work/run
```

`--pitch` は教師Ⅲの変換ピッチ（半音）です。0を固定値として採用する意味ではありません。まず教師音声を聴き、曇りや歪みの少ない設定を選んでから学習します。`--flatten` と `rmvpe` は公式LLVCのRVC教師生成例に合わせています。Ⅲの大きな検索インデックスはこの公式の例には組み込まれません。インデックスありのⅢの音と一致する保証はありません。

`teacher` は `train/dev/val` の3分割を生成し、形式やペアを検査します。`segment_llvc_pairs.py` は公式学習コードがWAV冒頭の65536サンプルしか読まないため、長いペアを4秒以下に切ります。最後の1秒未満は使いません。`prepare` は公式設定から学習用設定を作り、アプリの16kHz・208サンプルLLVC構造と照合します。公式設定で補助HuBERTモデルが必要なのに見つからない場合は、学習前にエラーにします。新規学習時は公式コードが生成器と判別器の重みを両方作成します。再実行すると両方あるチェックポイントから再開します。

## 学習後

`training-work/run/checkpoints/` の同じ番号の `G_*.pth` と `D_*.pth` が揃い、比較試聴で採用できた場合のみ、Android用ZIPを作成します。書出し時にはⅢの派生モデルの利用条件も満たすライセンス表示と正確な出典を指定してください。ZIPを作ればアプリの「話者モデルを追加」から調声モードへ切替可能です。訓練中の `.pth` や教師用 `.index` をAPKへ同梱しません。

学習後、派生モデルに適用する利用条件を `training-work/III-LLVC-LICENSE.txt` に記したうえで、次のコマンドでONNXを出力・一致検証し、Androidに取り込めるZIPを生成できます。`LicenseRef-Private` は個人検証用の例であり、再配布許可を意味しません。元となるⅢの利用条件に従って指定してください。

```bash
docker run --rm -v "$PWD:/project:ro" -v "$PWD/training-work:/work" \
  local-voice-llvc python /project/tools/finalize_llvc_voice.py \
  --repo /opt/llvc --run-dir /work/run \
  --license /work/III-LLVC-LICENSE.txt --license-spdx LicenseRef-Private \
  --output /work/iii-voice
```

生成物は `training-work/iii-voice.zip` です。非公開の学習済みLLVC重みは `local://trained/iii-llvc` として記録し、Ⅲの教師モデル公開ページは別の出典項目に記録します。公開されていない学習済み重みのURLを捏造しません。

実機で遅延と聞こえ方を確かめるまでは話者として採用しません。現作業環境にはDocker実行環境もCUDA GPUもⅢの重みもないため、コンテナの実ビルドと学習完了は未検証です。
