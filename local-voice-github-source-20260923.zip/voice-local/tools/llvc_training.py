#!/usr/bin/env python3
"""Run KoeAI's teacher-data creation and LLVC training without changing the APK."""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
import tempfile
from pathlib import Path

from check_llvc_teacher_pairs import check_dataset

APP_ROOT = Path(__file__).resolve().parents[1]
EXPECTED = json.loads((APP_ROOT / "models/llvc-official-config.json").read_text(encoding="utf-8"))


def official_repo(path: Path) -> Path:
    repo = path.resolve()
    for name in ("train.py", "model.py", "experiments/llvc/config.json", "minimal_rvc/_infer_folder.py", "LICENSE"):
        if not (repo / name).is_file():
            raise ValueError(f"公式LLVCファイルがありません: {repo / name}")
    return repo


def prepare(repo: Path, dataset: Path, run_dir: Path, batch_size: int | None = None) -> Path:
    repo = official_repo(repo)
    dataset = dataset.resolve()
    checked = check_dataset(dataset)
    if not checked["passed"]:
        raise ValueError("学習データが不正です: " + "; ".join(checked["issues"][:5]))
    template = json.loads((repo / "experiments/llvc/config.json").read_text(encoding="utf-8"))
    if template["data"]["sr"] != EXPECTED["data"]["sr"] or template["model_params"] != EXPECTED["model_params"]:
        raise ValueError("公式設定の構造がAPKのLLVCモデルと一致しません")
    if batch_size is not None and not 1 <= batch_size <= 128:
        raise ValueError("batch_sizeは1～128で指定してください")
    template["data"]["dir"] = str(dataset)
    template["test_dir"] = str(repo / "test_wavs")
    if batch_size:
        template["batch_size"] = batch_size
    if template.get("aux_fairseq", {}).get("c", 0) > 0:
        checkpoint = Path(template["aux_fairseq"]["checkpoint_path"])
        if not checkpoint.is_absolute():
            checkpoint = repo / checkpoint
        if not checkpoint.is_file():
            raise ValueError(f"HuBERT補助損失用モデルがありません: {checkpoint}。公式設定どおり事前に用意してください")
        template["aux_fairseq"]["checkpoint_path"] = str(checkpoint.resolve())
    path = run_dir.resolve() / "config.json"
    serialized = json.dumps(template, ensure_ascii=False, indent=2) + "\n"
    if path.exists():
        if path.read_text(encoding="utf-8") != serialized:
            raise ValueError("既存の学習設定と一致しません。別のrun-dirを指定してください")
        return path
    if (run_dir / "checkpoints").exists():
        raise ValueError("設定のない既存チェックポイントへは上書きしません")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(serialized, encoding="utf-8")
    return path


def teacher_command(repo: Path, checkpoint: Path, train: Path, dev: Path, output: Path,
                    pitch: int) -> list[str]:
    official_repo(repo)
    for path in (checkpoint, train, dev):
        if not path.exists() or (path == checkpoint and not path.is_file()) or (path != checkpoint and not path.is_dir()):
            raise ValueError(f"入力がありません: {path}")
    if output.exists():
        raise ValueError(f"出力先が既に存在します: {output}")
    if not -24 <= pitch <= 24:
        raise ValueError("変換ピッチは-24～24半音で指定してください")
    return [sys.executable, "-m", "minimal_rvc._infer_folder", "--train_set_path", str(train.resolve()),
            "--dev_set_path", str(dev.resolve()), "--out_path", str(output.resolve()), "--flatten",
            "--model_path", str(checkpoint.resolve()), "--model_name", "III", "--target_sr", "16000",
            "--f0_method", "rmvpe", "--val_percent", "0.02", "--random_seed", "42",
            "--f0_up_key", str(pitch)]


def require_cuda() -> None:
    try:
        import torch
    except ImportError as error:
        raise ValueError("PyTorchがありません。学習用コンテナで実行してください") from error
    if not torch.cuda.is_available() or torch.cuda.device_count() < 1:
        raise ValueError("CUDA GPUが認識されません。学習は開始しません")


def self_test() -> None:
    with tempfile.TemporaryDirectory() as temporary:
        root = Path(temporary)
        repo = root / "llvc"
        for filename in ("train.py", "model.py", "minimal_rvc/_infer_folder.py", "LICENSE"):
            path = repo / filename
            path.parent.mkdir(parents=True, exist_ok=True)
            path.touch()
        template = {"data": {"sr": 16000, "dir": "old", "wav_len": 65536},
                    "model_params": EXPECTED["model_params"], "aux_fairseq": {"c": 0},
                    "batch_size": 8, "test_dir": "test_wavs"}
        config = repo / "experiments/llvc/config.json"
        config.parent.mkdir(parents=True)
        config.write_text(json.dumps(template), encoding="utf-8")
        checkpoint = root / "III.pth"
        checkpoint.touch()
        train, dev = root / "train", root / "dev"
        train.mkdir()
        dev.mkdir()
        command = teacher_command(repo, checkpoint, train, dev, root / "teacher", 0)
        assert command[-1] == "0" and "--target_sr" in command
        try:
            teacher_command(repo, checkpoint, train, dev, train, 0)
            raise AssertionError("existing output accepted")
        except ValueError:
            pass
        import struct
        import wave
        for split in ("train", "dev", "val"):
            folder = root / "dataset" / split
            folder.mkdir(parents=True)
            for suffix in ("original", "converted"):
                with wave.open(str(folder / f"test_{suffix}.wav"), "wb") as audio:
                    audio.setparams((1, 2, 16000, 0, "NONE", "not compressed"))
                    audio.writeframes(struct.pack("<h", 1000) * 3200)
        run = root / "run"
        path = prepare(repo, root / "dataset", run, batch_size=2)
        assert json.loads(path.read_text())["data"]["dir"] == str((root / "dataset").resolve())
        assert prepare(repo, root / "dataset", run, batch_size=2) == path
        try:
            prepare(repo, root / "dataset", run, batch_size=3)
            raise AssertionError("changed training config accepted")
        except ValueError:
            pass
    print("PASS LLVC teacher command, training config and resume guards")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--self-test", action="store_true")
    sub = parser.add_subparsers(dest="action")
    doctor = sub.add_parser("doctor")
    doctor.add_argument("--repo", type=Path, required=True)
    teacher = sub.add_parser("teacher")
    teacher.add_argument("--repo", type=Path, required=True)
    teacher.add_argument("--checkpoint", type=Path, required=True)
    teacher.add_argument("--train-input", type=Path, required=True)
    teacher.add_argument("--dev-input", type=Path, required=True)
    teacher.add_argument("--output", type=Path, required=True)
    teacher.add_argument("--pitch", type=int, default=0)
    prep = sub.add_parser("prepare")
    prep.add_argument("--repo", type=Path, required=True)
    prep.add_argument("--dataset", type=Path, required=True)
    prep.add_argument("--run-dir", type=Path, required=True)
    prep.add_argument("--batch-size", type=int)
    train = sub.add_parser("train")
    train.add_argument("--repo", type=Path, required=True)
    train.add_argument("--run-dir", type=Path, required=True)
    args = parser.parse_args()
    try:
        if args.self_test:
            self_test()
        elif args.action == "doctor":
            repo = official_repo(args.repo)
            require_cuda()
            print("LLVC:", repo, "CUDA GPU: available")
        elif args.action == "teacher":
            require_cuda()
            command = teacher_command(args.repo, args.checkpoint, args.train_input, args.dev_input, args.output, args.pitch)
            subprocess.run(command, cwd=official_repo(args.repo), check=True)
            checked = check_dataset(args.output)
            if not checked["passed"]:
                raise ValueError("教師音声を確認してください: " + "; ".join(checked["issues"][:5]))
            print(json.dumps(checked, ensure_ascii=False))
        elif args.action == "prepare":
            print(prepare(args.repo, args.dataset, args.run_dir, args.batch_size))
        elif args.action == "train":
            repo = official_repo(args.repo)
            config = args.run_dir / "config.json"
            if not config.is_file():
                raise ValueError("先にprepareを実行してください")
            dataset = Path(json.loads(config.read_text(encoding="utf-8"))["data"]["dir"])
            checked = check_dataset(dataset)
            if not checked["passed"]:
                raise ValueError("学習データが不正です: " + "; ".join(checked["issues"][:5]))
            require_cuda()
            subprocess.run([sys.executable, str(repo / "train.py"), "-d", str(args.run_dir.resolve())],
                           cwd=repo, check=True)
        else:
            parser.error("doctor / teacher / prepare / train を指定してください")
    except ValueError as error:
        parser.exit(1, str(error) + "\n")


if __name__ == "__main__":
    main()
