#!/usr/bin/env python3
"""Preflight a synthetic original/converted dataset for LLVC training.

Does not generate audio, run a teacher, or train a model. It rejects obvious
pairing/format defects before expensive LLVC training is attempted.
"""

from __future__ import annotations

import argparse
import json
import math
import struct
import tempfile
import wave
from pathlib import Path


def inspect_wav(path: Path) -> dict[str, float | int]:
    with wave.open(str(path), "rb") as source:
        if source.getcomptype() != "NONE" or source.getnchannels() != 1 or source.getsampwidth() != 2:
            raise ValueError(f"16bit PCM・モノラルではありません: {path}")
        if source.getframerate() != 16000:
            raise ValueError(f"16kHzではありません: {path}")
        frames = source.getnframes()
        if frames < 1600:
            raise ValueError(f"0.1秒未満の音声です: {path}")
        square_sum = 0
        clip_count = 0
        read_frames = 0
        while chunk := source.readframes(8192):
            if len(chunk) % 2:
                raise ValueError(f"PCMデータが破損しています: {path}")
            samples = struct.iter_unpack("<h", chunk)
            for (sample,) in samples:
                square_sum += sample * sample
                clip_count += abs(sample) >= 32760
                read_frames += 1
        if read_frames != frames:
            raise ValueError(f"WAVヘッダーと音声長が一致しません: {path}")
        rms_dbfs = 20 * math.log10(max(math.sqrt(square_sum / frames) / 32768, 1e-12))
        return {"frames": frames, "rms_dbfs": round(rms_dbfs, 2), "clip_fraction": clip_count / frames}


def check_dataset(root: Path) -> dict[str, object]:
    if not root.is_dir():
        raise ValueError(f"データセットが見つかりません: {root}")
    issues: list[str] = []
    counts: dict[str, int] = {}
    seconds = 0.0
    for split in ("train", "dev", "val"):
        folder = root / split
        if not folder.is_dir():
            issues.append(f"{split}: フォルダがありません")
            counts[split] = 0
            continue
        names = {file.name for file in folder.glob("*.wav") if file.is_file()}
        originals = {name[:-len("_original.wav")] for name in names if name.endswith("_original.wav")}
        converted = {name[:-len("_converted.wav")] for name in names if name.endswith("_converted.wav")}
        counts[split] = len(originals & converted)
        for name in sorted(names - {f"{key}_original.wav" for key in originals}
                           - {f"{key}_converted.wav" for key in converted}):
            issues.append(f"{split}: 対応外のWAV名: {name}")
        for key in sorted(originals ^ converted):
            issues.append(f"{split}/{key}: 元音声と教師音声が揃っていません")
        for key in sorted(originals & converted):
            try:
                source = inspect_wav(folder / f"{key}_original.wav")
                target = inspect_wav(folder / f"{key}_converted.wav")
                seconds += int(source["frames"]) / 16000
                difference = abs(int(source["frames"]) - int(target["frames"]))
                if difference > 320:
                    issues.append(f"{split}/{key}: 音声長が20ms超ずれています ({difference} samples)")
                if float(source["rms_dbfs"]) < -50 or float(target["rms_dbfs"]) < -50:
                    issues.append(f"{split}/{key}: 無音に近い音声があります")
                if float(source["clip_fraction"]) > 0.01 or float(target["clip_fraction"]) > 0.01:
                    issues.append(f"{split}/{key}: クリッピングが1%を超えます")
            except (OSError, EOFError, ValueError, wave.Error) as error:
                issues.append(f"{split}/{key}: {error}")
        if not counts[split]:
            issues.append(f"{split}: 対応する音声ペアがありません")
    return {"passed": not issues, "pairs": counts, "source_hours": round(seconds / 3600, 3), "issues": issues}


def self_test() -> None:
    with tempfile.TemporaryDirectory() as temporary:
        root = Path(temporary)
        for split in ("train", "dev", "val"):
            folder = root / split
            folder.mkdir()
            for suffix in ("original", "converted"):
                with wave.open(str(folder / f"sample_{suffix}.wav"), "wb") as target:
                    target.setparams((1, 2, 16000, 0, "NONE", "not compressed"))
                    target.writeframes(struct.pack("<h", 1000) * 3200)
        assert check_dataset(root)["passed"] is True
        (root / "train" / "sample_converted.wav").unlink()
        result = check_dataset(root)
        assert result["passed"] is False and any("揃って" in issue for issue in result["issues"])
        with wave.open(str(root / "train" / "sample_converted.wav"), "wb") as target:
            target.setparams((1, 2, 16000, 0, "NONE", "not compressed"))
            target.writeframes(struct.pack("<h", 1000) * 2400)
        assert any("20ms超" in issue for issue in check_dataset(root)["issues"])
    print("PASS LLVC teacher pairs, missing targets and duration drift")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("dataset", nargs="?", type=Path)
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()
    if args.self_test:
        self_test()
    elif args.dataset:
        result = check_dataset(args.dataset)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        if not result["passed"]:
            raise SystemExit(1)
    else:
        parser.error("datasetフォルダを指定してください")


if __name__ == "__main__":
    main()
