#!/usr/bin/env python3
"""Export the official stateful LLVC stream to an offline Android model package."""

from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import sys
from pathlib import Path
from typing import Any


def flatten_tree(value: Any) -> tuple[list[Any], Any]:
    if value is None:
        return [], {"kind": "none"}
    if isinstance(value, (tuple, list)):
        leaves: list[Any] = []
        children = []
        for child in value:
            child_leaves, child_spec = flatten_tree(child)
            leaves.extend(child_leaves)
            children.append(child_spec)
        return leaves, {"kind": "tuple" if isinstance(value, tuple) else "list", "children": children}
    return [value], {"kind": "leaf"}


def unflatten_tree(leaves: list[Any] | tuple[Any, ...], spec: Any, position: int = 0) -> tuple[Any, int]:
    kind = spec["kind"]
    if kind == "none":
        return None, position
    if kind == "leaf":
        if position >= len(leaves):
            raise ValueError("状態テンソルが不足")
        return leaves[position], position + 1
    values = []
    for child in spec["children"]:
        value, position = unflatten_tree(leaves, child, position)
        values.append(value)
    return (tuple(values) if kind == "tuple" else values), position


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def self_test() -> None:
    source = (["a", ("b", None)], "c")
    leaves, spec = flatten_tree(source)
    rebuilt, used = unflatten_tree(leaves, spec)
    assert leaves == ["a", "b", "c"] and rebuilt == source and used == len(leaves)
    try:
        unflatten_tree([], {"kind": "leaf"})
        raise AssertionError("missing leaf accepted")
    except ValueError:
        pass
    print("PASS LLVC state-tree flatten and reconstruction")


def export(args: argparse.Namespace) -> None:
    try:
        import torch
    except ImportError as error:
        raise SystemExit("PyTorchが必要です。公式LLVC環境で実行してください。") from error

    repo = args.llvc_repo.resolve()
    checkpoint = args.checkpoint.resolve()
    config_path = args.config.resolve()
    license_path = args.license.resolve()
    for path in (repo / "model.py", checkpoint, config_path, license_path):
        if not path.is_file():
            raise SystemExit(f"必要ファイルがありません: {path}")
    sys.path.insert(0, str(repo))
    from model import Net  # type: ignore[import-not-found]  # official LLVC source

    config = json.loads(config_path.read_text(encoding="utf-8"))
    if config["data"]["sr"] != 16000 or config["model_params"]["L"] * config["model_params"]["dec_chunk_size"] != 208:
        raise SystemExit("このアプリが固定した16kHz/208サンプル構成ではありません")
    model = Net(**config["model_params"])
    payload = torch.load(checkpoint, map_location="cpu")
    if not isinstance(payload, dict) or "model" not in payload:
        raise SystemExit("公式LLVC state_dict形式ではありません")
    model.load_state_dict(payload["model"], strict=True)
    model.eval()
    enc_buf, dec_buf, out_buf = model.init_buffers(1, torch.device("cpu"))
    conv_ctx = model.convnet_pre.init_ctx_buf(1, torch.device("cpu")) if hasattr(model, "convnet_pre") else None
    state_tree = (enc_buf, dec_buf, out_buf, conv_ctx)
    state_leaves, state_spec = flatten_tree(state_tree)
    if not state_leaves or any(not isinstance(item, torch.Tensor) for item in state_leaves):
        raise SystemExit("未対応のLLVC状態構造です")

    class StreamingWrapper(torch.nn.Module):
        def __init__(self, inner: Any) -> None:
            super().__init__()
            self.inner = inner

        def forward(self, audio: Any, *flat_state: Any) -> Any:
            states, used = unflatten_tree(flat_state, state_spec)
            if used != len(flat_state):
                raise RuntimeError("状態テンソル数が不一致")
            converted = self.inner(audio, *states, pad=(not self.inner.lookahead))
            audio_out, next_states = converted[0], converted[1:]
            next_leaves, next_spec = flatten_tree(next_states)
            if next_spec != state_spec or len(next_leaves) != len(state_leaves):
                raise RuntimeError("入出力の状態構造が不一致")
            return (audio_out, *next_leaves)

    wrapper = StreamingWrapper(model).eval()
    # Official streaming inference prepends the previous 32 samples as
    # look-ahead context and feeds 208 new samples (240 total). The model
    # emits 208 samples, which is the hop used by the Android bridge.
    audio = torch.zeros(1, 1, 240, dtype=torch.float32)
    # The official streaming model updates several buffers in-place. Keep a
    # pristine copy for ONNX inputs so PyTorch and ONNX see identical state.
    state_leaves = [tensor.detach().to(dtype=torch.float32, device="cpu").contiguous().clone() for tensor in state_leaves]
    torch_state_inputs = [tensor.clone() for tensor in state_leaves]
    with torch.inference_mode():
        dry_run = wrapper(audio, *torch_state_inputs)
    if dry_run[0].numel() != 208:
        raise SystemExit("LLVC音声出力が208サンプルではありません")

    destination = args.output.resolve()
    destination.mkdir(parents=True, exist_ok=True)
    model_path = destination / "llvc.onnx"
    input_names = ["audio", *[f"state_{index}" for index in range(len(state_leaves))]]
    output_names = ["audio_out", *[f"state_{index}_out" for index in range(len(state_leaves))]]
    export_options = dict(input_names=input_names, output_names=output_names, opset_version=args.opset, do_constant_folding=True)
    export_state_inputs = [tensor.clone() for tensor in state_leaves]
    ort_state_inputs = [tensor.clone() for tensor in state_leaves]
    try:
        torch.onnx.export(wrapper, (audio, *export_state_inputs), model_path, dynamo=False, **export_options)
    except TypeError:
        torch.onnx.export(wrapper, (audio, *export_state_inputs), model_path, **export_options)
    if not model_path.is_file() or model_path.stat().st_size < 1024:
        raise SystemExit("ONNX出力に失敗しました")

    try:
        import numpy as np
        import onnxruntime as ort
    except ImportError as error:
        raise SystemExit("変換結果の一致確認にnumpyとonnxruntimeが必要です") from error
    session = ort.InferenceSession(str(model_path), providers=["CPUExecutionProvider"])
    ort_inputs = {name: tensor.detach().cpu().numpy() for name, tensor in zip(input_names, (audio, *ort_state_inputs))}
    ort_outputs = session.run(output_names, ort_inputs)
    torch_outputs = [tensor.detach().cpu().numpy() for tensor in dry_run]
    if len(ort_outputs) != len(torch_outputs):
        raise SystemExit("ONNX出力数がPyTorch版と一致しません")
    errors = []
    for name, expected, actual in zip(output_names, torch_outputs, ort_outputs):
        if expected.shape != actual.shape or not np.all(np.isfinite(actual)):
            raise SystemExit(f"ONNX出力が不正です: {name}")
        maximum = float(np.max(np.abs(expected - actual))) if expected.size else 0.0
        errors.append(maximum)
        # The legacy TorchScript exporter can differ by a few 1e-4 around
        # zero for LayerNorm/attention kernels; retain a stricter-than-audio
        # tolerance while accepting that known numerical noise.
        if not np.allclose(expected, actual, rtol=2e-3, atol=5e-4):
            raise SystemExit(f"ONNX出力がPyTorch版と一致しません: {name}, max_abs={maximum:.8g}")

    license_target = destination / "LICENSE.model.txt"
    shutil.copy2(license_path, license_target)
    state_contract = [
        {"input_name": input_names[index + 1], "output_name": output_names[index + 1], "shape": list(tensor.shape)}
        for index, tensor in enumerate(state_leaves)
    ]
    manifest = {
        "schema_version": 1,
        "engine_id": args.engine_id,
        "display_name": args.display_name,
        "runtime": "onnxruntime-mobile",
        "model_format": "onnx",
        "model_file": model_path.name,
        "model_sha256": sha256(model_path),
        "sample_rate_hz": 16000,
        "input_channels": 1,
        "streaming": True,
        "stateful": True,
        "frame_samples": 208,
        "license_spdx": args.license_spdx,
        "license_file": license_target.name,
        "source_url": args.source_url,
        "checkpoint_source_url": args.checkpoint_source_url,
        **({"teacher_source_url": args.teacher_source_url} if args.teacher_source_url else {}),
        "checkpoint_sha256": sha256(checkpoint),
        "source_config_sha256": sha256(config_path),
        "conversion_validation": {
            "passed": True,
            "onnxruntime_version": ort.__version__,
            "tested_frames": 1,
            "max_abs_error": max(errors, default=0.0),
        },
        "target_voice_description": str(config["data"].get("dir", "official LLVC target")),
        "runtime_contract": {
            "audio_input_name": input_names[0],
            "audio_output_name": output_names[0],
            "state_tensors": state_contract,
        },
    }
    manifest_path = destination / "model-package.json"
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"model": str(model_path), "manifest": str(manifest_path), "sha256": manifest["model_sha256"],
                      "states": len(state_contract), "bytes": model_path.stat().st_size}, ensure_ascii=False, indent=2))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument("--llvc-repo", type=Path)
    parser.add_argument("--checkpoint", type=Path)
    parser.add_argument("--config", type=Path)
    parser.add_argument("--license", type=Path)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--engine-id", default="llvc-f8312-onnx-v1")
    parser.add_argument("--display-name", default="LLVC female candidate")
    parser.add_argument("--opset", type=int, default=17)
    parser.add_argument("--license-spdx", default="MIT")
    parser.add_argument("--source-url", default="https://github.com/KoeAI/LLVC")
    parser.add_argument("--checkpoint-source-url", default="https://huggingface.co/KoeAI/llvc_models")
    parser.add_argument("--teacher-source-url")
    args = parser.parse_args()
    if args.self_test:
        self_test()
        return
    missing = [name for name in ("llvc_repo", "checkpoint", "config", "license", "output") if getattr(args, name) is None]
    if missing:
        parser.error("不足引数: " + ", ".join(missing))
    if not args.display_name.strip() or len(args.display_name) > 48 or "\n" in args.display_name:
        parser.error("話者名は1〜48文字の単一行で指定してください")
    export(args)


if __name__ == "__main__":
    main()
