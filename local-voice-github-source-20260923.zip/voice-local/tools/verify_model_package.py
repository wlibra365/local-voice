#!/usr/bin/env python3
"""Validate an offline voice-model package before it enters the Android build."""

from __future__ import annotations

import argparse
import hashlib
import json
import tempfile
from pathlib import Path


REQUIRED = {
    "schema_version", "engine_id", "display_name", "runtime", "model_format", "model_file",
    "model_sha256", "sample_rate_hz", "input_channels", "streaming",
    "stateful", "frame_samples",
    "license_spdx", "license_file", "source_url", "checkpoint_source_url",
    "runtime_contract",
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def validate(manifest_path: Path) -> dict[str, object]:
    data = json.loads(manifest_path.read_text(encoding="utf-8"))
    missing = sorted(REQUIRED - data.keys())
    if missing:
        raise ValueError("不足項目: " + ", ".join(missing))
    if data["schema_version"] != 1:
        raise ValueError("未対応schema_version")
    if data["input_channels"] != 1 or data["sample_rate_hz"] not in (16000, 24000, 32000, 44100, 48000):
        raise ValueError("音声形式が未対応")
    if data["streaming"] is not True:
        raise ValueError("リアルタイム候補はstreaming=trueが必要")
    if data["stateful"] is not True or not isinstance(data["frame_samples"], int) or not 1 <= data["frame_samples"] <= 8192:
        raise ValueError("ストリーミング状態またはフレーム長が不正")
    contract = data["runtime_contract"]
    if not isinstance(contract, dict) or not isinstance(contract.get("audio_input_name"), str) or not contract["audio_input_name"]:
        raise ValueError("音声入力名が不正")
    if not isinstance(contract.get("audio_output_name"), str) or not contract["audio_output_name"]:
        raise ValueError("音声出力名が不正")
    states = contract.get("state_tensors")
    if not isinstance(states, list) or not 1 <= len(states) <= 16:
        raise ValueError("状態テンソル定義が不正")
    names: set[str] = {contract["audio_input_name"], contract["audio_output_name"]}
    total_elements = 0
    for state in states:
        if not isinstance(state, dict) or set(state) != {"input_name", "output_name", "shape"}:
            raise ValueError("状態テンソル項目が不正")
        for key in ("input_name", "output_name"):
            name = state[key]
            if not isinstance(name, str) or not name or name in names:
                raise ValueError("状態テンソル名が不正または重複")
            names.add(name)
        shape = state["shape"]
        if not isinstance(shape, list) or not 1 <= len(shape) <= 8 or any(type(value) is not int or value <= 0 for value in shape):
            raise ValueError("状態テンソル形状が不正")
        elements = 1
        for value in shape:
            elements *= value
            if elements > 16_000_000:
                raise ValueError("状態テンソルが大きすぎます")
        total_elements += elements
    if total_elements > 16_000_000:
        raise ValueError("状態テンソル合計が大きすぎます")
    if data["model_format"] == "onnx":
        validation = data.get("conversion_validation")
        if not isinstance(validation, dict) or validation.get("passed") is not True:
            raise ValueError("ONNX変換一致検証がありません")
        if type(validation.get("tested_frames")) is not int or validation["tested_frames"] < 1:
            raise ValueError("ONNX検証フレーム数が不正")
        error = validation.get("max_abs_error")
        if not isinstance(error, (int, float)) or not 0 <= error <= 0.01:
            raise ValueError("ONNX変換誤差が不正")
    if not isinstance(data["source_url"], str) or not data["source_url"].startswith("https://"):
        raise ValueError("source_urlが不正")
    checkpoint_url = data["checkpoint_source_url"]
    if not isinstance(checkpoint_url, str) or not (checkpoint_url.startswith("https://")
                                                   or checkpoint_url.startswith("local://trained/")):
        raise ValueError("checkpoint_source_urlが不正")
    root = manifest_path.parent
    model = root / str(data["model_file"])
    license_path = root / str(data["license_file"])
    if not model.is_file() or not license_path.is_file():
        raise ValueError("モデルまたはライセンスファイルがありません")
    expected = str(data["model_sha256"])
    if len(expected) != 64 or expected.lower() != expected or any(c not in "0123456789abcdef" for c in expected):
        raise ValueError("model_sha256が不正")
    actual = sha256(model)
    if actual != expected:
        raise ValueError("モデルSHA-256不一致")
    if license_path.stat().st_size < 20:
        raise ValueError("ライセンス本文が空または短すぎます")
    return {"engine_id": data["engine_id"], "model_sha256": actual, "model_bytes": model.stat().st_size,
            "sample_rate_hz": data["sample_rate_hz"], "license_spdx": data["license_spdx"]}


def self_test() -> None:
    with tempfile.TemporaryDirectory() as directory:
        root = Path(directory)
        model = root / "model.bin"
        model.write_bytes(b"local voice candidate model test")
        (root / "LICENSE.txt").write_text("MIT License test fixture only", encoding="utf-8")
        manifest = {
            "schema_version": 1, "engine_id": "test", "display_name": "test", "runtime": "test", "model_format": "test",
            "model_file": model.name, "model_sha256": sha256(model), "sample_rate_hz": 16000,
            "input_channels": 1, "streaming": True, "stateful": True, "frame_samples": 208, "license_spdx": "MIT",
            "license_file": "LICENSE.txt", "source_url": "https://example.invalid/source",
            "checkpoint_source_url": "https://example.invalid/model",
            "runtime_contract": {"audio_input_name": "audio", "audio_output_name": "audio_out",
                                 "state_tensors": [{"input_name": "state", "output_name": "state_out", "shape": [1, 4, 8]}]},
        }
        path = root / "model-package.json"
        path.write_text(json.dumps(manifest), encoding="utf-8")
        validate(path)
        manifest["checkpoint_source_url"] = "local://trained/iii-llvc"
        path.write_text(json.dumps(manifest), encoding="utf-8")
        validate(path)
        manifest["checkpoint_source_url"] = "file:///untrusted"
        path.write_text(json.dumps(manifest), encoding="utf-8")
        try:
            validate(path)
            raise AssertionError("invalid checkpoint provenance accepted")
        except ValueError as error:
            if "checkpoint_source_url" not in str(error):
                raise
        manifest["checkpoint_source_url"] = "local://trained/iii-llvc"
        manifest["model_sha256"] = "0" * 64
        path.write_text(json.dumps(manifest), encoding="utf-8")
        try:
            validate(path)
            raise AssertionError("hash mismatch accepted")
        except ValueError as error:
            if "SHA-256" not in str(error):
                raise
    print("PASS model package manifest, license presence and SHA-256 rejection")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("manifest", nargs="?", type=Path)
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()
    if args.self_test:
        self_test()
    elif args.manifest:
        print(json.dumps(validate(args.manifest), ensure_ascii=False, indent=2))
    else:
        parser.error("manifestが必要です")


if __name__ == "__main__":
    main()
