#!/usr/bin/env python3
"""Validate and export a trained LLVC checkpoint as an Android speaker ZIP."""

from __future__ import annotations

import argparse
import json
import re
import subprocess
import sys
import tempfile
from pathlib import Path

from llvc_training import official_repo
from package_speaker_model import pack
from verify_model_package import validate


def latest_complete_checkpoint(run_dir: Path) -> tuple[Path, int]:
    folder = run_dir / "checkpoints"
    complete = []
    for generator in folder.glob("G_*.pth"):
        match = re.fullmatch(r"G_([1-9][0-9]*)\.pth", generator.name)
        if match and generator.is_file() and (folder / f"D_{match.group(1)}.pth").is_file():
            complete.append(int(match.group(1)))
    if not complete:
        raise ValueError("同じ番号のG/Dチェックポイントがありません")
    step = max(complete)
    return folder / f"G_{step}.pth", step


def finalize(repo: Path, run_dir: Path, license_file: Path, license_spdx: str,
             checkpoint_url: str, teacher_url: str, output_dir: Path,
             display_name: str = "Ⅲ声 LLVC 試作") -> Path:
    repo = official_repo(repo)
    config = run_dir / "config.json"
    if not config.is_file():
        raise ValueError("学習設定がありません")
    generator, step = latest_complete_checkpoint(run_dir)
    if not license_file.is_file() or license_file.stat().st_size < 20 or not license_spdx.strip():
        raise ValueError("派生モデルのライセンス本文と識別子を指定してください")
    if not (checkpoint_url.startswith("https://") or checkpoint_url.startswith("local://trained/")):
        raise ValueError("学習済み重みの出典が不正です")
    if not teacher_url.startswith("https://"):
        raise ValueError("教師モデルの出典が不正です")
    if not display_name.strip() or len(display_name) > 48 or "\n" in display_name:
        raise ValueError("話者名は1～48文字の一行で指定してください")
    output_dir = output_dir.resolve()
    archive = output_dir.with_suffix(".zip")
    if output_dir.exists() or archive.exists():
        raise ValueError("出力先が既に存在します")
    command = [sys.executable, str(Path(__file__).with_name("export_llvc_onnx.py")),
               "--llvc-repo", str(repo), "--checkpoint", str(generator.resolve()),
               "--config", str(config.resolve()), "--license", str(license_file.resolve()),
               "--output", str(output_dir), "--engine-id", "llvc-iii-student-v1",
               "--display-name", display_name, "--license-spdx", license_spdx,
               "--source-url", "https://github.com/KoeAI/LLVC",
               "--checkpoint-source-url", checkpoint_url, "--teacher-source-url", teacher_url]
    subprocess.run(command, check=True)
    info = validate(output_dir / "model-package.json")
    if info["model_bytes"] > 48 * 1024 * 1024:
        raise ValueError("Androidのモデルサイズ上限48MiBを超えています")
    pack(output_dir, archive)
    print(json.dumps({"step": step, "zip": str(archive), "sha256": info["model_sha256"]},
                     ensure_ascii=False, indent=2))
    return archive


def self_test() -> None:
    with tempfile.TemporaryDirectory() as temporary:
        root = Path(temporary)
        folder = root / "checkpoints"
        folder.mkdir()
        for name in ("G_9.pth", "D_9.pth", "G_11.pth", "D_11.pth", "G_12.pth"):
            (folder / name).write_bytes(b"fixture")
        assert latest_complete_checkpoint(root) == (folder / "G_11.pth", 11)
        (folder / "D_11.pth").unlink()
        assert latest_complete_checkpoint(root) == (folder / "G_9.pth", 9)
        (folder / "D_9.pth").unlink()
        try:
            latest_complete_checkpoint(root)
            raise AssertionError("unpaired checkpoint accepted")
        except ValueError:
            pass
    print("PASS paired LLVC checkpoint selection and missing discriminator rejection")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument("--repo", type=Path)
    parser.add_argument("--run-dir", type=Path)
    parser.add_argument("--license", type=Path)
    parser.add_argument("--license-spdx")
    parser.add_argument("--checkpoint-source-url", default="local://trained/iii-llvc")
    parser.add_argument("--teacher-source-url", default="https://huggingface.co/ttttdiva/rvc_okiba/tree/main/models/III")
    parser.add_argument("--display-name", default="Ⅲ声 LLVC 試作")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    if args.self_test:
        self_test()
        return
    for name in ("repo", "run_dir", "license", "license_spdx", "output"):
        if getattr(args, name) is None:
            parser.error("不足引数: " + name)
    try:
        finalize(args.repo, args.run_dir, args.license, args.license_spdx,
                 args.checkpoint_source_url, args.teacher_source_url, args.output, args.display_name)
    except ValueError as error:
        parser.exit(1, str(error) + "\n")


if __name__ == "__main__":
    main()
