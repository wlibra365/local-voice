#!/usr/bin/env bash
set -euo pipefail

# Supply the official Linux command-line tools ZIP on first setup. SDK remains
# outside the source archive; the download and license acceptance are explicit.
sdk_root="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-$PWD/.android-sdk}}"
sdkmanager="${SDKMANAGER:-$sdk_root/cmdline-tools/latest/bin/sdkmanager}"
if [[ ! -x "$sdkmanager" ]]; then
  archive="${1:-}"
  if [[ -z "$archive" || ! -f "$archive" ]]; then
    echo "公式Android Command-line Tools (Linux) ZIPを取得し、そのパスを第1引数に指定してください。" >&2
    echo "https://developer.android.com/studio#command-line-tools-only" >&2
    exit 2
  fi
  expected_sha="4e4c464f145a7512b57d088ac6c278c03c9eea610886b35a5e0804e74eedf583"
  if ! printf '%s  %s\n' "$expected_sha" "$archive" | sha256sum --check --status; then
    echo "公式Linux版 commandlinetools-linux-15859902_latest.zip のSHA-256と一致しません。" >&2
    exit 2
  fi
  mkdir -p "$sdk_root/cmdline-tools/latest"
  unzip -oq "$archive" 'cmdline-tools/*' -d "$sdk_root/cmdline-tools/latest"
  # Google's archive contains an extra cmdline-tools directory.
  mv "$sdk_root/cmdline-tools/latest/cmdline-tools/"* "$sdk_root/cmdline-tools/latest/"
  rmdir "$sdk_root/cmdline-tools/latest/cmdline-tools"
fi
"$sdkmanager" --sdk_root="$sdk_root" --licenses
"$sdkmanager" --sdk_root="$sdk_root" \
  "platform-tools" \
  "platforms;android-35" \
  "build-tools;35.0.0"
cat <<EOF
SDK準備完了: $sdk_root
次の環境変数を設定してください:
  export ANDROID_SDK_ROOT="$sdk_root"
ビルド:
  ./build-apk.sh
EOF
