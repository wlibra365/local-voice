#!/usr/bin/env python3
"""Pack a converted LLVC voice as the three-file archive accepted by the Android app."""

import argparse
import hashlib
import json
import tempfile
import zipfile
from pathlib import Path

NAMES = ("llvc.onnx", "model-package.json", "LICENSE.model.txt")


def pack(folder: Path, output: Path) -> None:
    if output.exists():
        raise ValueError(f"出力先がすでに存在します: {output}")
    files = [folder / name for name in NAMES]
    if any(not file.is_file() for file in files):
        raise ValueError("llvc.onnx、model-package.json、LICENSE.model.txt が必要です")
    manifest = json.loads(files[1].read_text(encoding="utf-8"))
    if (manifest.get("model_file") != NAMES[0]
            or manifest.get("license_file") != NAMES[2]
            or manifest.get("model_format") != "onnx"
            or manifest.get("schema_version") != 1):
        raise ValueError("このアプリ向けのLLVCマニフェストではありません")
    if not manifest.get("display_name") or len(manifest["display_name"]) > 48:
        raise ValueError("display_name を1〜48文字で指定してください")
    with files[0].open("rb") as source:
        digest = hashlib.file_digest(source, "sha256").hexdigest()
    if digest != manifest.get("model_sha256"):
        raise ValueError("ONNXのSHA-256がマニフェストと一致しません")
    if files[0].stat().st_size > 48 * 1024 * 1024:
        raise ValueError("モデルは48MB以下にしてください")
    with zipfile.ZipFile(output, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for file in files:
            archive.write(file, arcname=file.name)


def self_test() -> None:
    with tempfile.TemporaryDirectory() as directory:
        root = Path(directory)
        (root / NAMES[0]).write_bytes(b"test-onnx")
        (root / NAMES[2]).write_text("MIT license for a test model", encoding="utf-8")
        (root / NAMES[1]).write_text(json.dumps({
            "model_file": NAMES[0], "license_file": NAMES[2],
            "model_format": "onnx", "schema_version": 1, "display_name": "試験話者",
            "model_sha256": hashlib.sha256(b"test-onnx").hexdigest(),
        }), encoding="utf-8")
        output = root / "speaker.zip"
        pack(root, output)
        with zipfile.ZipFile(output) as archive:
            assert set(archive.namelist()) == set(NAMES)
        try:
            pack(root, output)
            raise AssertionError("existing file overwritten")
        except ValueError:
            pass
        (root / NAMES[0]).write_bytes(b"corrupt")
        try:
            pack(root, root / "invalid.zip")
            raise AssertionError("hash mismatch accepted")
        except ValueError:
            pass
    print("PASS speaker-model ZIP packaging and hash rejection")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument("--package", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    if args.self_test:
        self_test()
    elif args.package is None or args.output is None:
        parser.error("--package と --output を指定してください")
    else:
        pack(args.package, args.output)
        print(args.output)
