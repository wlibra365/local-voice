#!/usr/bin/env python3
"""Split aligned 16kHz PCM16 LLVC training pairs into at most four-second clips."""

from __future__ import annotations

import argparse
import tempfile
import wave
from pathlib import Path

from check_llvc_teacher_pairs import check_dataset

FRAME_LIMIT = 64000  # Official LLVC dataset.py only takes the first 65536 samples.
MIN_TAIL = 16000


def segments(source: Path, output: Path) -> dict[str, int]:
    result = check_dataset(source)
    if not result["passed"]:
        raise ValueError("教師データが不正です: " + "; ".join(result["issues"][:5]))
    if output.exists():
        raise ValueError(f"出力先が存在します: {output}")
    for split in ("train", "dev", "val"):
        if not any((source / split).glob("*_original.wav")):
            raise ValueError(f"{split} に音声ペアがありません")
    counts: dict[str, int] = {}
    for split in ("train", "dev", "val"):
        pairs = sorted((source / split).glob("*_original.wav"))
        counts[split] = 0
        for original in pairs:
            converted = original.with_name(original.name.replace("_original.wav", "_converted.wav"))
            with wave.open(str(original), "rb") as dry, wave.open(str(converted), "rb") as wet:
                available = min(dry.getnframes(), wet.getnframes())
                offset = 0
                part = 0
                while available - offset >= MIN_TAIL:
                    length = min(FRAME_LIMIT, available - offset)
                    for suffix, reader in (("original", dry), ("converted", wet)):
                        reader.setpos(offset)
                        target_path = output / split / f"{original.stem[:-len('_original')]}_part{part:04d}_{suffix}.wav"
                        target_path.parent.mkdir(parents=True, exist_ok=True)
                        with wave.open(str(target_path), "wb") as target:
                            target.setparams((1, 2, 16000, 0, "NONE", "not compressed"))
                            target.writeframes(reader.readframes(length))
                    offset += length
                    part += 1
                    counts[split] += 1
    if not all(counts.values()):
        raise ValueError("各分割に1秒以上の音声が必要です")
    return counts


def self_test() -> None:
    import struct

    with tempfile.TemporaryDirectory() as temporary:
        source = Path(temporary) / "source"
        output = Path(temporary) / "output"
        for split in ("train", "dev", "val"):
            (source / split).mkdir(parents=True)
            for suffix in ("original", "converted"):
                with wave.open(str(source / split / f"phrase_{suffix}.wav"), "wb") as wav:
                    wav.setparams((1, 2, 16000, 0, "NONE", "not compressed"))
                    wav.writeframes(struct.pack("<h", 1000) * 112000)
        assert segments(source, output) == {"train": 2, "dev": 2, "val": 2}
        assert check_dataset(output)["passed"]
        for wav in output.rglob("*.wav"):
            with wave.open(str(wav)) as reader:
                assert reader.getnframes() <= FRAME_LIMIT
        try:
            segments(source, output)
            raise AssertionError("existing output overwritten")
        except ValueError:
            pass
    print("PASS LLVC dataset segmenting, pairing, and overwrite guard")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", nargs="?", type=Path)
    parser.add_argument("output", nargs="?", type=Path)
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()
    if args.self_test:
        self_test()
        return
    if not args.source or not args.output:
        parser.error("source と output を指定してください")
    print(segments(args.source, args.output))


if __name__ == "__main__":
    main()
