# 工程B：変換エンジン候補

確認日：2026-09-22

## 第一候補：LLVC

KoeAI LLVCは、リアルタイムのany-to-one音声変換をCPUで低遅延・低負荷に動かす目的の公開実装です。リポジトリはMITライセンスで、事前学習モデルも公開されています。まずホスト上で同じ男性音声を変換し、工程Aの評価基盤で女性声らしさ・透明感・自然さ・明瞭さを測ります。

公式設定を固定して確認した実行契約は16kHz、`L=16`、`dec_chunk_size=13`で、入力フレームは208サンプル（13ms）です。公開チェックポイント `G_500000.pth` は配布ページ上39.5MBです。Android側には44.1/48kHzと16kHzを接続し、208サンプルごとに状態付きカーネルを呼ぶブリッジを追加しました。モデル推論そのものは未接続です。

Android側の状態付きONNX推論アダプターまで実装済みです。エクスポート時にPyTorch版とONNX Runtime版の全出力を比較し、入出力名・状態形状・誤差をモデルパッケージへ固定します。モデルとONNX Runtime Mobile AARが揃わないAPKではLLVCを選択しません。

- 実装：https://github.com/KoeAI/LLVC
- 論文：https://arxiv.org/abs/2311.00873
- 公開モデル：https://huggingface.co/KoeAI/llvc_models

採用未確定事項：公開女性ターゲットの日本語適性、モデルと依存物を含む再配布条件、Androidへの書き出し可否、利用端末での速度・発熱・遅延。

## Android実行候補：ONNX Runtime Mobile

ONNX Runtime MobileはAndroid上の推論とJava/C++ APIを公式に提供します。LLVCモデルをONNXへ正しく書き出せ、ホスト版と出力が一致する場合の候補です。モデル書き出し成功を前提にせず、演算子対応、状態キャッシュ、量子化による音質差を検証します。

- 公式：https://onnxruntime.ai/docs/get-started/with-mobile.html
- モバイル配備：https://onnxruntime.ai/docs/tutorials/mobile/

## 保留：StreamVC

StreamVC論文はモバイル上のリアルタイム動作を報告していますが、今回確認できた公式公開物から、アプリへ組み込める学習済み実装一式を確定できませんでした。研究結果だけを根拠に実装済み候補とは扱いません。

- 公式研究ページ：https://research.google/pubs/streamvc-real-time-low-latency-voice-conversion/

## 比較基準

同じ入力音声、同じ発話区間、音量合わせ後のWAVで旧DSPと候補を比較します。品質基準を通過するまで通常録音エンジンへ切り替えません。方式名、公開デモ、処理速度だけでは採用しません。
# 再調査（2026-09-23）

StreamVCは論文でモバイル端末上の低遅延変声を報告している。ただし調査した非公式PyTorch実装は、学習済みチェックポイントを公開しておらず、論文のストリーミング推論も未実装と明記している。現時点でアプリに投入できる追加女性声の実体として数えない。既存LLVC公開チェックポイントは単一の対象話者で、設定・後処理差分を別話者として登録しない。
